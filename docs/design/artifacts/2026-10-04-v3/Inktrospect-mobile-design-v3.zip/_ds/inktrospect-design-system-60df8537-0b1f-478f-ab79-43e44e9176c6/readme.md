# Inktrospect Design System

**Inktrospect — Your handwriting, measured.** A privacy-conscious consumer handwriting-analysis app for web, iPhone/iPad and Android. Users upload or capture a page of handwriting and receive a highly visual personal report built on deterministic measurements of handwriting geometry, with evidence showing where and how each result was derived. Free uses zero runtime AI. Optional Premium adds bounded AI-assisted interpretation on top of the same saved measurements and never replaces or invents them. Product surfaces: capture/upload, processing and first reveal, the report (the core product), evidence, history, comparison (planned), PDF export, share cards and settings.

**Chosen direction:** *A · The Dossier*, plus B's loupe inspector and fixed-scale range bars and C's colour-plane share cards. Light-first, with a "night paper" dark theme. The direction explorations are kept in `directions/` for reference. Status: draft; the repo's `design_acceptance` owner gate is still pending.

## Sources
- GitHub: **https://github.com/HMarcusWH/YouAreASpecialLittlePrincess** (`main`). This repo is the product authority; it uses the working name *You Are A Special Little Princess*. Explore it further to design against the real contracts:
  - `docs/design/CLAUDE_DESIGN_HANDOFF.md`, `docs/design/README.md`: screen/state matrix, component inventory, prohibited patterns
  - `packages/design-tokens/tokens.json`: engineering token defaults (role names kept here)
  - `packages/report-web/src/` (ReportView, EvidenceView, messages.ts EN/SV) and `packages/report-core/src/` (formatFact, charts)
  - `apps/web/app/`: current routes (start/upload, analyses/processing, reports, settings)
  - `fixtures/reports/`: synthetic projections; three are copied to `fixtures/reports/` here
- **No logo exists** in the source. The wordmark is the name set in Newsreader 500 (`guidelines/wordmark.html`). Do not draw a mark.

## Index
- `styles.css`: entry point (imports only) → `tokens/fonts.css`, `tokens/colors.css`, `tokens/typography.css`, `tokens/layout.css`, `components/ink.css`
- `guidelines/`: foundation specimen cards (Colors, Type, Spacing, Brand)
- `components/`: React primitives, one directory per concern, each with a card
- `ui_kits/app/`: web app click-through (`index.html`)
- `directions/`: the three original explorations (A Dossier, B Loupe, C Recap)
- `fixtures/reports/`: synthetic data from the repo
- `SKILL.md`: agent-skill entry. `github.md`: source sync record

## Components
Namespace `window.InktrospectDesignSystem_60df85`.
- **evidence/**: EvidenceBadge, FactValue, QualityHint, NoticeBar (+ `messages.js`: EN/SV strings and `formatFact` ported from the repo)
- **report/**: Standout, ReportSection, MarginNote, Button, ActionBar
- **charts/**: HandwritingCanvas (plate + overlays + loupe), LayerToggles, SlantFan, BaselineTrace, SpacingChart, RangeBar, PageMap, plus the SampleEvidence and SampleFacts fixture exports
- **flow/**: UploadField, ConsentChoice, JobStatus, CreditBalance
- **share/**: ShareCard

Repo inventory mapping (`docs/design/README.md` §3): FactValue, EvidenceBadge, QualityHint, ReportSection, NoticeBar, ActionBar, HandwritingCanvas, DistributionChart → **SlantFan**, BaselineTrace, SpacingChart, JobStatus, CreditBalance, ConsentChoice, ShareCard.

**Intentional additions:** Button (shared action primitive), Standout (the opening statement, with an illustrative marker), MarginNote (the dossier's numbered evidence note), LayerToggles (plate layers + legend), RangeBar (the fixed-scale bars borrowed from B), PageMap (a share-safe layout visual), UploadField (capture drop zone).

## Content fundamentals
- **Voice:** a careful, curious observer. Plain English, specific, second person ("your letters", "your lines"). Share cards switch to first person ("My writing leans right.") because the user is the one speaking.
- **One statement per section**, written as an observation about this page: "Almost every letter we could read leans to the right." Then a lede with the actual numbers: "Of the 26 letter shapes accepted for slant, one stood upright and none leaned left."
- **Describe, never diagnose.** "Wider spacing" stays a spacing fact. No personality, intelligence, honesty, health, hiring or compatibility language. No praise ("beautiful", "unique"), and no rarity, percentile, "Top X%" or social proof unless a named reference group is in the contract.
- **Limits are written calmly and specifically:** "Not measured in this sample. Each line was read as a single word, so there were no gaps to measure." / "No eligible reference group yet — nothing here is ranked against other writers." / "0.78 on a 0–1 engineering index — not a percentage."
- **Casing:** sentence case for headings and buttons ("Export PDF", "See where it was measured"). Mono UPPERCASE only for small labels/kickers ("WHAT STANDS OUT", "MEAN SLANT").
- **Units always shown:** px, °, × x-height, "/ 0–1 index". Swedish uses a decimal comma via `Intl.NumberFormat`; long compounds (Bokstavsavståndsvariation) wrap rather than being abbreviated.
- **Kickers:** "What stands out", "A closer look", "At a glance", "Explore the evidence", "What changed", "Most alike", "Biggest difference".
- **No emoji.** The wit comes from precise observation. Leave the ink puns to the name.
- **Premium copy** is a truthful product description with no blurred or teaser text. AI is "AI-assisted", never "our AI discovered".

## Visual foundations
- **Colour:** warm paper (`--paper #F3EEE4`) with iron-gall ink (`--ink #1C1A17`). A single red-pencil annotation colour (`--pencil #A8361B`) is used for annotations, kickers and hover; blue-black (`--annot-2`) is the second annotation voice (margins). Evidence and state colours keep the repo's role names and hues. Share planes (cobalt, tomato, butter, moss) appear **only** on share cards, as chapter colours, and never encode evidence class. No gradients, except hatch and ruled-paper patterns.
- **Dark ("night paper"):** warm near-black surfaces. The **specimen plate stays light** (the light-table idea from B), so the handwriting and its annotations read the same in both themes (`--plate-*` tokens are fixed).
- **Type:** Newsreader for everything editorial. Statements are italic 300 at 72px with a −0.025em letter-spacing; headings italic 300 at 44px; body 17/1.55 at a 34rem measure. Values are serif with tabular lining figures. IBM Plex Mono is for kickers, labels, units, method ids and region ids. Cedarville Cursive appears **only** as illustrative stand-in glyphs on the plate.
- **Layout:** the dossier page is a single column of sections divided by hairline rules. Each section holds one statement or heading, one figure (Fig. 1, Fig. 2…) and 2–4 numbered margin notes on the right; on narrow screens the notes stack below. Generous whitespace (48–96px between sections), max content width 72rem, 56px gutters on desktop and 20px on narrow screens.
- **Handwriting is the hero:** the plate (`--paper-plate`, a 1px rule, no radius) is the largest object on the report. Overlays are fine 1–1.5px lines drawn in the evidence coordinate frame: baseline polylines with points, slant ticks at each component, spacing brackets, margin washes, x-height band. Rejected observations are dashed and pale, never hidden.
- **Loupe:** a 180px circle with a pencil ring, magnifying 2.6×, with a black mono readout ("Slant 22.9° · accepted"). It opens on hover, or on focus with ←/→; on touch it's press-and-hold and it sits above the finger.
- **Charts:** fixed scales only. Slant uses a −90…+90° fan and range bar; range bars show a P05–P95 band plus a mean mark. No radar charts, no smoothing, no per-person rescaling. Missing data gets a hatched mark, never a zero bar.
- **Cards and boxes:** almost none inside the report; hairline rules do the structuring. The only shadow is `--shadow-sheet` on outer sheets and share previews. Corners are near-square (2px on controls, 0 on plates and cards). Pills are reserved for status dots.
- **Borders encode evidence structure:** badge underline solid = Measured, dashed = Computed proxy, double = Reference, none = Authored. Traditional content sits on ruled paper; AI content sits in its own bordered panel.
- **Buttons:** primary is solid ink on paper, secondary is outlined, ghost is text. Hover fills or underlines in pencil red; press nudges 1px down. Disabled buttons are dashed with a visible reason, never faded to 60%. Focus is a 3px `--focus` ring with a 2px offset. Minimum target 44px.
- **Motion:** overlays draw along their path (600ms, standard easing), state changes take 120–200ms, and there's no bounce, parallax or shimmer. Under reduced motion everything is 0ms and reveals are instant, never skipped.
- **Imagery:** no photography or illustration. The user's own handwriting (when permitted) is the only image. Share cards use derived visuals (fan, traces, page map) and never the writing itself.
- **Transparency/blur:** only the pencil wash (8%) on bands and margins. No glass or blur.
- **Print (A4/Letter):** paper theme, 18mm margins, 10.5pt base, all details expanded, actions hidden, colophon with report id, revision, method and limitations.

## Iconography
- The icon set is **Unicode glyphs**, taken from the repo's `EVIDENCE_ICON` map: ◆ Measured, ◇ Computed proxy, ▲ Reference, ✎ Authored, ☾ Traditional, ✦ AI-assisted. State marks added here: ⌂ locked/private, ▢ image omitted, ✓ done, ! failed, → continue, and numbered circles for margin notes. See `guidelines/iconography.html`.
- There's no icon font, SVG sprite or PNG icon set in the repo. None was substituted: the glyph approach is deliberate and prints and localises cleanly. If a platform-native icon is needed (share sheet, close), use SF Symbols on iOS and Material Symbols on Android — **flag it as an addition**.
- No emoji. Glyphs are always paired with a text label.

## Product rules (never break)
- Missing ≠ 0. Not calibrated ≠ a confidence percentage. Indices are "/ 0–1 index".
- In the current fixture almost every handwriting value is **Computed proxy**; only image metadata is Measured. Label them honestly.
- **"What stands out" stays illustrative** (with an `Illustrative selection` marker) until a **server-owned, versioned salience contract** exists. Never calculate it on the client.
- Reference ranks need an eligible named group. Traditional content stays source-labelled and inactive. AI is a separate overlay.
- A purchase state and a permission state are separate. Share and export read saved content and never trigger a new model call.

## Proposed contract changes (flagged, not invented)
1. A salience/standout field (server-owned, versioned) for "What stands out", "Most distinctive in this sample" and "Your most stable feature".
2. A string for `reason.premium_not_yet_available` (drafted as "Premium isn't available yet.").
3. Reviewed feature display names (T08) and reviewed fixed chart scales (the slant histogram and the margin 0–20 × x-height scale are proposed).
4. A comparison DTO (T18/T22). The Compare screen is structure only.

## Fonts (substitution flag)
The repo specifies only system stacks. Newsreader, IBM Plex Mono and Cedarville Cursive are loaded from Google Fonts via `@import` in `tokens/fonts.css`; no font binaries are bundled. Provide licensed files if you want them self-hosted.
