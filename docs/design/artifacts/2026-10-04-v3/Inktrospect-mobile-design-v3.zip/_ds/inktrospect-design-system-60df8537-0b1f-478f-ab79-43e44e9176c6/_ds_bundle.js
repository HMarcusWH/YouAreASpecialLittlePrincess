/* @ds-bundle: {"format":4,"namespace":"InktrospectDesignSystem_60df85","components":[{"name":"BaselineTrace","sourcePath":"components/charts/BaselineTrace.jsx"},{"name":"SampleEvidence","sourcePath":"components/charts/sampleEvidence.js"},{"name":"SampleFacts","sourcePath":"components/charts/sampleEvidence.js"},{"name":"HandwritingCanvas","sourcePath":"components/charts/HandwritingCanvas.jsx"},{"name":"LayerToggles","sourcePath":"components/charts/LayerToggles.jsx"},{"name":"PageMap","sourcePath":"components/charts/PageMap.jsx"},{"name":"RangeBar","sourcePath":"components/charts/RangeBar.jsx"},{"name":"SlantFan","sourcePath":"components/charts/SlantFan.jsx"},{"name":"SpacingChart","sourcePath":"components/charts/SpacingChart.jsx"},{"name":"EvidenceBadge","sourcePath":"components/evidence/EvidenceBadge.jsx"},{"name":"FactValue","sourcePath":"components/evidence/FactValue.jsx"},{"name":"NoticeBar","sourcePath":"components/evidence/NoticeBar.jsx"},{"name":"QualityHint","sourcePath":"components/evidence/QualityHint.jsx"},{"name":"EVIDENCE_GLYPH","sourcePath":"components/evidence/messages.js"},{"name":"ConsentChoice","sourcePath":"components/flow/ConsentChoice.jsx"},{"name":"CreditBalance","sourcePath":"components/flow/CreditBalance.jsx"},{"name":"JobStatus","sourcePath":"components/flow/JobStatus.jsx"},{"name":"UploadField","sourcePath":"components/flow/UploadField.jsx"},{"name":"ActionBar","sourcePath":"components/report/ActionBar.jsx"},{"name":"Button","sourcePath":"components/report/Button.jsx"},{"name":"MarginNote","sourcePath":"components/report/MarginNote.jsx"},{"name":"ReportSection","sourcePath":"components/report/ReportSection.jsx"},{"name":"Standout","sourcePath":"components/report/Standout.jsx"},{"name":"ShareCard","sourcePath":"components/share/ShareCard.jsx"}],"sourceHashes":{"components/charts/BaselineTrace.jsx":"922998462829","components/charts/HandwritingCanvas.jsx":"f410acfbfc36","components/charts/LayerToggles.jsx":"104eb546ccb4","components/charts/PageMap.jsx":"bd629d02df29","components/charts/RangeBar.jsx":"ca7e012d36b7","components/charts/SlantFan.jsx":"7ab121425bb8","components/charts/SpacingChart.jsx":"05c1acace7e8","components/charts/sampleEvidence.js":"a5d288b39d10","components/evidence/EvidenceBadge.jsx":"0e6195dca337","components/evidence/FactValue.jsx":"d2348ee3626f","components/evidence/NoticeBar.jsx":"08e0d01b0651","components/evidence/QualityHint.jsx":"9c24dd287962","components/evidence/messages.js":"c11092331a9c","components/flow/ConsentChoice.jsx":"4d53706adaf0","components/flow/CreditBalance.jsx":"26348e7c105e","components/flow/JobStatus.jsx":"c189070d61ab","components/flow/UploadField.jsx":"447c25bb1c58","components/report/ActionBar.jsx":"0ba8c53c8f2d","components/report/Button.jsx":"7ce4ac7dd68a","components/report/MarginNote.jsx":"1853339a27c0","components/report/ReportSection.jsx":"ee4b15701d3d","components/report/Standout.jsx":"ccd5f54e9a50","components/share/ShareCard.jsx":"9f8645d66a50","directions/ink-data.js":"886d0e3a5937","directions/specimen.js":"f9add3f5afba","ui_kits/app/capture-screen.jsx":"24139622371a","ui_kits/app/history-screen.jsx":"0f890d051911","ui_kits/app/processing-screen.jsx":"fdb25572bf7a","ui_kits/app/report-screen.jsx":"e3888ab5bd21","ui_kits/app/share-screen.jsx":"36f37afb559e","ui_kits/app/shell.jsx":"0b137d7d53f4"},"inlinedExternals":[],"unexposedExports":[{"name":"formatFact","sourcePath":"components/evidence/messages.js"},{"name":"t","sourcePath":"components/evidence/messages.js"}]} */

(() => {

const __ds_ns = (window.InktrospectDesignSystem_60df85 = window.InktrospectDesignSystem_60df85 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/charts/BaselineTrace.jsx
try { (() => {
function BaselineTrace({
  baselines,
  exaggerate = 3,
  rowHeight = 40,
  strokeWidth = 2,
  color = "var(--text-body)",
  dots = true,
  labels
}) {
  const w = 460,
    h = rowHeight * baselines.length;
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${w} ${h}`,
    width: "100%",
    role: "img",
    "aria-label": `${baselines.length} baseline traces from stored baseline points; vertical deviation exaggerated ${exaggerate}×.`,
    style: {
      display: "block"
    }
  }, baselines.map((pts, i) => {
    const my = pts.reduce((s, p) => s + p[1], 0) / pts.length,
      cy = rowHeight * (i + .5),
      x0 = pts[0][0],
      x1 = pts[pts.length - 1][0];
    const P = pts.map(p => [(p[0] - x0) * (w - (labels ? 90 : 20)) / Math.max(1, x1 - x0) + 10, cy + (p[1] - my) * exaggerate / 3]);
    return /*#__PURE__*/React.createElement("g", {
      key: i
    }, /*#__PURE__*/React.createElement("line", {
      x1: "0",
      y1: cy,
      x2: w,
      y2: cy,
      stroke: "var(--hatch)",
      strokeDasharray: "2 4",
      vectorEffect: "non-scaling-stroke"
    }), /*#__PURE__*/React.createElement("polyline", {
      points: P.map(p => p.join(",")).join(" "),
      fill: "none",
      stroke: color,
      strokeWidth: strokeWidth,
      strokeLinejoin: "round",
      vectorEffect: "non-scaling-stroke"
    }), dots && P.map((p, j) => /*#__PURE__*/React.createElement("circle", {
      key: j,
      cx: p[0],
      cy: p[1],
      r: "2.2",
      fill: color
    })), labels && /*#__PURE__*/React.createElement("text", {
      x: w - 4,
      y: cy + 4,
      textAnchor: "end",
      fontFamily: "var(--font-mono)",
      fontSize: "11",
      fill: "var(--text-muted)"
    }, labels[i]));
  }));
}
Object.assign(__ds_scope, { BaselineTrace });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/charts/BaselineTrace.jsx", error: String((e && e.message) || e) }); }

// components/charts/LayerToggles.jsx
try { (() => {
const NAMES = {
  baseline: "Baseline",
  slant: "Slant",
  spacing: "Line spacing",
  margins: "Margins",
  xheight: "x-height",
  lines: "Lines",
  components: "Components"
};
function LayerToggles({
  value,
  onChange,
  layers = ["baseline", "slant", "spacing", "margins", "xheight", "lines", "components"],
  labels = NAMES,
  exclusive = false
}) {
  const toggle = k => {
    if (exclusive) return onChange([k]);
    onChange(value.includes(k) ? value.filter(x => x !== k) : [...value, k]);
  };
  return /*#__PURE__*/React.createElement("div", {
    role: "group",
    "aria-label": "Evidence layers",
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 6
    }
  }, layers.map(k => /*#__PURE__*/React.createElement("button", {
    key: k,
    type: "button",
    className: "ik-tog",
    "aria-pressed": value.includes(k),
    onClick: () => toggle(k)
  }, labels[k] ?? k)));
}
Object.assign(__ds_scope, { LayerToggles });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/charts/LayerToggles.jsx", error: String((e && e.message) || e) }); }

// components/charts/PageMap.jsx
try { (() => {
function PageMap({
  frame,
  lines,
  marginLabels,
  ink = "var(--text-body)",
  paper = "var(--surface-plate)",
  fontSize = 18
}) {
  const right = Math.max(...lines.map(l => l[0] + l[2])),
    left = Math.min(...lines.map(l => l[0]));
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${frame.w} ${frame.h}`,
    width: "100%",
    role: "img",
    "aria-label": "Page map: position of the text lines on the analysis canvas, with left and right margins.",
    style: {
      display: "block"
    }
  }, /*#__PURE__*/React.createElement("rect", {
    x: "1",
    y: "1",
    width: frame.w - 2,
    height: frame.h - 2,
    fill: paper,
    stroke: ink,
    strokeWidth: "1.5",
    vectorEffect: "non-scaling-stroke"
  }), lines.map((l, i) => /*#__PURE__*/React.createElement("rect", {
    key: i,
    x: l[0],
    y: l[1] + 8,
    width: l[2],
    height: l[3] - 12,
    fill: ink
  })), [left, right].map(x => /*#__PURE__*/React.createElement("line", {
    key: x,
    x1: x,
    y1: "16",
    x2: x,
    y2: frame.h - 16,
    stroke: ink,
    strokeDasharray: "4 5",
    vectorEffect: "non-scaling-stroke"
  })), marginLabels && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("text", {
    x: (right + frame.w) / 2,
    y: frame.h / 2,
    textAnchor: "middle",
    fontFamily: "var(--font-mono)",
    fontSize: fontSize,
    fill: ink
  }, marginLabels.right), /*#__PURE__*/React.createElement("text", {
    x: left + 6,
    y: frame.h - 14,
    fontFamily: "var(--font-mono)",
    fontSize: fontSize,
    fill: ink
  }, marginLabels.left)));
}
Object.assign(__ds_scope, { PageMap });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/charts/PageMap.jsx", error: String((e && e.message) || e) }); }

// components/charts/RangeBar.jsx
try { (() => {
function RangeBar({
  domain,
  value = null,
  band,
  ticks,
  unit = "",
  label,
  format = v => String(v),
  missingLabel = "Not measured in this sample"
}) {
  const [a, b] = domain,
    pct = v => (v - a) / (b - a) * 100;
  const tk = ticks ?? [a, (a + b) / 2, b];
  return /*#__PURE__*/React.createElement("div", {
    role: "img",
    "aria-label": `${label ? label + ": " : ""}${value === null ? missingLabel : format(value) + unit} on a fixed scale from ${format(a)}${unit} to ${format(b)}${unit}${band ? `; band ${format(band[0])} to ${format(band[1])}${unit}` : ""}.`
  }, label && /*#__PURE__*/React.createElement("div", {
    className: "ik-cap",
    style: {
      marginBottom: 8
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    className: "ik-range__track"
  }, value === null ? /*#__PURE__*/React.createElement("div", {
    className: "ik-hatch",
    style: {
      position: "absolute",
      inset: "10px 0 auto",
      height: 14
    }
  }) : /*#__PURE__*/React.createElement(React.Fragment, null, band && /*#__PURE__*/React.createElement("div", {
    className: "ik-range__band",
    style: {
      left: pct(band[0]) + "%",
      width: pct(band[1]) - pct(band[0]) + "%"
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "ik-range__mark",
    style: {
      left: pct(value) + "%"
    }
  })), tk.map(t => /*#__PURE__*/React.createElement("div", {
    key: t,
    className: "ik-range__tick",
    style: {
      left: pct(t) + "%"
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "ik-range__labels"
  }, tk.map(t => /*#__PURE__*/React.createElement("span", {
    key: t
  }, format(t), unit))));
}
Object.assign(__ds_scope, { RangeBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/charts/RangeBar.jsx", error: String((e && e.message) || e) }); }

// components/charts/SlantFan.jsx
try { (() => {
function SlantFan({
  observations,
  mean = null,
  showRejected = true,
  labels = true,
  strokeWidth = 1.5,
  color = "var(--text-body)",
  accent = "var(--text-accent)",
  title = "Slant observations on a fixed scale from 90° left to 90° right."
}) {
  const R = 100;
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: `${-R - 14} ${-R - 18} ${2 * R + 28} ${R + 32}`,
    width: "100%",
    role: "img",
    "aria-label": title,
    style: {
      display: "block"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: `M${-R},0 A${R},${R} 0 0 1 ${R},0`,
    fill: "none",
    stroke: "var(--rule-strong)",
    vectorEffect: "non-scaling-stroke"
  }), /*#__PURE__*/React.createElement("line", {
    x1: -R,
    y1: "0",
    x2: R,
    y2: "0",
    stroke: "var(--rule-strong)",
    vectorEffect: "non-scaling-stroke"
  }), [-60, -30, 0, 30, 60].map(a => {
    const t = a * Math.PI / 180;
    return /*#__PURE__*/React.createElement("g", {
      key: a
    }, /*#__PURE__*/React.createElement("line", {
      x1: Math.sin(t) * R,
      y1: -Math.cos(t) * R,
      x2: Math.sin(t) * (R + 5),
      y2: -Math.cos(t) * (R + 5),
      stroke: "var(--rule-strong)",
      vectorEffect: "non-scaling-stroke"
    }), labels && /*#__PURE__*/React.createElement("text", {
      x: Math.sin(t) * (R + 12),
      y: -Math.cos(t) * (R + 12) + 3,
      fontFamily: "var(--font-mono)",
      fontSize: "8",
      fill: "var(--text-muted)",
      textAnchor: "middle"
    }, (a > 0 ? "+" : "") + a + "°"));
  }), observations.map((o, i) => {
    if (o.value === null || !o.accepted && !showRejected) return null;
    const t = o.value * Math.PI / 180,
      r = R * 0.92;
    return /*#__PURE__*/React.createElement("line", {
      key: i,
      x1: "0",
      y1: "0",
      x2: Math.sin(t) * r,
      y2: -Math.cos(t) * r,
      stroke: o.accepted ? color : "var(--hatch)",
      strokeWidth: o.accepted ? strokeWidth : 1,
      strokeDasharray: o.accepted ? undefined : "2 3",
      opacity: o.accepted ? .85 : .8,
      vectorEffect: "non-scaling-stroke"
    });
  }), mean !== null && /*#__PURE__*/React.createElement("line", {
    x1: "0",
    y1: "0",
    x2: Math.sin(mean * Math.PI / 180) * (R + 4),
    y2: -Math.cos(mean * Math.PI / 180) * (R + 4),
    stroke: accent,
    strokeWidth: "3",
    strokeLinecap: "round",
    vectorEffect: "non-scaling-stroke"
  }), /*#__PURE__*/React.createElement("circle", {
    r: "3",
    fill: mean !== null ? accent : color
  }));
}
Object.assign(__ds_scope, { SlantFan });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/charts/SlantFan.jsx", error: String((e && e.message) || e) }); }

// components/charts/SpacingChart.jsx
try { (() => {
function SpacingChart({
  gaps,
  unit = "px",
  max,
  label = "Line gap",
  locale = "en"
}) {
  const top = max ?? Math.max(...gaps.filter(g => g.value !== null).map(g => g.value), 1);
  const nf = new Intl.NumberFormat(locale === "sv" ? "sv-SE" : "en-GB", {
    maximumFractionDigits: 1
  });
  return /*#__PURE__*/React.createElement("table", {
    style: {
      width: "100%",
      borderCollapse: "collapse"
    }
  }, /*#__PURE__*/React.createElement("caption", {
    className: "ik-visually-hidden"
  }, label, " observations"), /*#__PURE__*/React.createElement("tbody", null, gaps.map((g, i) => /*#__PURE__*/React.createElement("tr", {
    key: i,
    style: {
      borderTop: "1px solid var(--border-hairline)"
    }
  }, /*#__PURE__*/React.createElement("th", {
    scope: "row",
    className: "ik-cap",
    style: {
      textAlign: "start",
      padding: "10px 12px 10px 0",
      whiteSpace: "nowrap",
      fontWeight: 500
    }
  }, g.from, " \u2192 ", g.to), /*#__PURE__*/React.createElement("td", {
    style: {
      width: "60%",
      padding: "10px 0"
    }
  }, g.value === null ? /*#__PURE__*/React.createElement("div", {
    className: "ik-hatch",
    style: {
      height: 14
    },
    "aria-hidden": "true"
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 6,
      width: `${g.value / top * 100}%`,
      borderTop: `1.5px ${g.accepted ? "solid" : "dashed"} ${g.accepted ? "var(--text-accent)" : "var(--hatch)"}`
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      height: 14,
      borderLeft: "1.5px solid var(--text-accent)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: `${g.value / top * 100}%`,
      top: 0,
      height: 14,
      borderLeft: `1.5px solid ${g.accepted ? "var(--text-accent)" : "var(--hatch)"}`
    }
  }))), /*#__PURE__*/React.createElement("td", {
    className: "ik-value ik-value--sm",
    style: {
      textAlign: "end",
      padding: "10px 0 10px 12px",
      whiteSpace: "nowrap"
    }
  }, g.value === null ? /*#__PURE__*/React.createElement("em", {
    className: "ik-hint"
  }, "\u2014") : /*#__PURE__*/React.createElement(React.Fragment, null, nf.format(g.value), /*#__PURE__*/React.createElement("span", {
    className: "ik-value__unit"
  }, unit))), /*#__PURE__*/React.createElement("td", {
    className: "ik-hint",
    style: {
      padding: "10px 0 10px 12px",
      fontSize: "var(--font-size-xs)"
    }
  }, g.accepted ? "Accepted" : `Rejected${g.reason ? ": " + g.reason : ""}`)))));
}
Object.assign(__ds_scope, { SpacingChart });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/charts/SpacingChart.jsx", error: String((e && e.message) || e) }); }

// components/charts/sampleEvidence.js
try { (() => {
// Synthetic fixture evidence (HMarcusWH/YouAreASpecialLittlePrincess fixtures/reports/evidence-bundle.json + view.free.json).
// Frame frame_analysis 713x316 px. components: [x, y, w, h, slantDeg|null, accepted 1|0|null]. Never real handwriting.
const SampleEvidence = {
  "frame": {
    "w": 713,
    "h": 316
  },
  "lines": [[31, 64, 419, 30], [31, 142, 315, 31], [32, 219, 347, 32]],
  "baselines": [[[31, 73], [71, 85], [119, 86], [151, 86], [191, 82], [223, 84], [263, 74], [311, 84], [343, 73], [375, 86], [407, 84], [447, 82]], [[31, 161], [61, 160], [85, 156], [121, 163], [151, 155], [175, 164], [199, 159], [229, 163], [253, 163], [295, 164], [319, 162], [343, 157]], [[32, 230], [62, 237], [92, 228], [116, 240], [152, 241], [182, 240], [212, 239], [248, 239], [290, 238], [314, 228], [344, 235], [374, 238]]],
  "baselineAngles": [-0.201, -0.748, -0.301],
  "lineGaps": [48, 46],
  "components": [[296, 63, 15, 25, 22.89, 1], [31, 64, 13, 24, 5.07, 1], [44, 64, 19, 24, -1.66, 0], [136, 64, 5, 4, null, null], [159, 64, 18, 24, 6.14, 1], [186, 64, 18, 24, 4.44, 0], [359, 64, 5, 4, null, null], [65, 70, 17, 18, 35.14, 0], [92, 70, 19, 24, 6.04, 0], [113, 71, 18, 17, 58.86, 0], [132, 71, 8, 17, 13.6, 1], [141, 70, 17, 18, 28.17, 0], [206, 71, 14, 17, 30.98, 1], [220, 70, 17, 18, 40.58, 0], [241, 71, 25, 17, 80.03, 0], [266, 70, 19, 18, 56.05, 0], [308, 70, 18, 18, 40.49, 0], [326, 71, 20, 17, 34.28, 0], [350, 71, 13, 23, 19.38, 1], [364, 71, 18, 17, 56.69, 0], [383, 70, 28, 18, 83.16, 0], [412, 70, 19, 24, 34.69, 1], [433, 70, 17, 18, 21.13, 1], [214, 142, 9, 24, 12.65, 1], [287, 142, 20, 24, 35.06, 1], [31, 148, 17, 18, 39.46, 0], [52, 148, 17, 18, 36.71, 0], [69, 148, 17, 18, 33.34, 0], [87, 148, 15, 18, 31.5, 1], [109, 148, 19, 18, 40.61, 0], [139, 148, 17, 18, 38.16, 0], [156, 148, 17, 18, 33.84, 0], [174, 148, 33, 24, 81.12, 0], [223, 148, 19, 18, 40.12, 0], [242, 148, 17, 18, 17.07, 1], [261, 148, 18, 24, 24.12, 1], [307, 148, 18, 18, 40.26, 0], [325, 148, 21, 25, 22.52, 1], [75, 219, 5, 5, null, null], [97, 219, 5, 5, null, null], [274, 219, 15, 25, 23.76, 1], [290, 219, 5, 5, null, null], [80, 220, 13, 24, 5.09, 1], [237, 220, 9, 24, 12.55, 1], [314, 220, 13, 24, 4.87, 1], [32, 226, 25, 18, 79.33, 0], [57, 226, 15, 18, 31.77, 1], [71, 226, 7, 18, 12.41, 1], [93, 226, 8, 18, 12.24, 1], [102, 226, 18, 18, 54.01, 0], [121, 226, 20, 25, 24.11, 1], [151, 226, 16, 18, 20.3, 1], [168, 226, 19, 18, 41.13, 0], [187, 226, 28, 18, 83.84, 0], [215, 226, 20, 24, 34.35, 1], [247, 226, 17, 18, 34.3, 0], [286, 226, 8, 18, 12.89, 1], [293, 226, 20, 18, 27.84, 0], [328, 226, 19, 18, 53.69, 0], [348, 226, 14, 18, 30.8, 1], [362, 226, 17, 18, 33.98, 0]],
  "xHeight": 18,
  "glyphText": ["Handwriting is a quiet", "record of how I", "think on paper"]
};
const SampleFacts = {
  "IMG_WIDTH_PX": {
    "feature_id": "IMG_WIDTH_PX",
    "value": 900,
    "unit": "px",
    "availability": "READY",
    "evidence_class": "MEASURED",
    "precision": 1,
    "formatting_key": "measurement.px",
    "method_id": "input_dimensions_v1",
    "quality": {
      "n_observations": 1,
      "missing_reason": null,
      "confidence_kind": "EXACT_CONDITIONAL"
    }
  },
  "IMG_HEIGHT_PX": {
    "feature_id": "IMG_HEIGHT_PX",
    "value": 360,
    "unit": "px",
    "availability": "READY",
    "evidence_class": "MEASURED",
    "precision": 1,
    "formatting_key": "measurement.px",
    "method_id": "input_dimensions_v1",
    "quality": {
      "n_observations": 1,
      "missing_reason": null,
      "confidence_kind": "EXACT_CONDITIONAL"
    }
  },
  "IMG_MEGAPIXELS": {
    "feature_id": "IMG_MEGAPIXELS",
    "value": 0.324,
    "unit": "MP",
    "availability": "READY",
    "evidence_class": "MEASURED",
    "precision": 2,
    "formatting_key": "measurement.MP",
    "method_id": "input_dimensions_v1",
    "quality": {
      "n_observations": 1,
      "missing_reason": null,
      "confidence_kind": "EXACT_CONDITIONAL"
    }
  },
  "IMG_ASPECT_RATIO": {
    "feature_id": "IMG_ASPECT_RATIO",
    "value": 2.5,
    "unit": "ratio",
    "availability": "READY",
    "evidence_class": "MEASURED",
    "precision": 2,
    "formatting_key": "measurement.ratio",
    "method_id": "input_dimensions_v1",
    "quality": {
      "n_observations": 1,
      "missing_reason": null,
      "confidence_kind": "EXACT_CONDITIONAL"
    }
  },
  "IMG_ROTATION_DEG": {
    "feature_id": "IMG_ROTATION_DEG",
    "value": 3.0000000000000426,
    "unit": "degrees",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 1,
    "formatting_key": "measurement.degrees",
    "method_id": "text_skew_ccw_v1",
    "quality": {
      "n_observations": 1,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "PAGE_LINE_COUNT": {
    "feature_id": "PAGE_LINE_COUNT",
    "value": 3,
    "unit": "count",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 0,
    "formatting_key": "measurement.count",
    "method_id": "accepted_segmentation_census_v1",
    "quality": {
      "n_observations": 1,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "PAGE_WORD_COUNT": {
    "feature_id": "PAGE_WORD_COUNT",
    "value": 3,
    "unit": "count",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 0,
    "formatting_key": "measurement.count",
    "method_id": "accepted_segmentation_census_v1",
    "quality": {
      "n_observations": 1,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "PAGE_COMPONENT_COUNT": {
    "feature_id": "PAGE_COMPONENT_COUNT",
    "value": 61,
    "unit": "count",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 0,
    "formatting_key": "measurement.count",
    "method_id": "accepted_segmentation_census_v1",
    "quality": {
      "n_observations": 1,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "PAGE_INK_AREA_RATIO": {
    "feature_id": "PAGE_INK_AREA_RATIO",
    "value": 0.044357057894082765,
    "unit": "ratio",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.ratio",
    "method_id": "accepted_segmentation_census_v1",
    "quality": {
      "n_observations": 1,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "PAGE_TEXT_AREA_RATIO": {
    "feature_id": "PAGE_TEXT_AREA_RATIO",
    "value": 0.34775951142436135,
    "unit": "ratio",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.ratio",
    "method_id": "accepted_segmentation_census_v1",
    "quality": {
      "n_observations": 1,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "X_HEIGHT_PX": {
    "feature_id": "X_HEIGHT_PX",
    "value": 18,
    "unit": "px",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 1,
    "formatting_key": "measurement.px",
    "method_id": "component_height_mode_v1",
    "quality": {
      "n_observations": 37,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "GLYPH_HEIGHT_MEAN": {
    "feature_id": "GLYPH_HEIGHT_MEAN",
    "value": 19.982142857142858,
    "unit": "px",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 1,
    "formatting_key": "measurement.px",
    "method_id": "component_box_size_v1",
    "quality": {
      "n_observations": 56,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "GLYPH_HEIGHT_CV": {
    "feature_id": "GLYPH_HEIGHT_CV",
    "value": 0.15117040917710878,
    "unit": "cv",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.cv",
    "method_id": "component_box_size_v1",
    "quality": {
      "n_observations": 56,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "GLYPH_WIDTH_MEAN": {
    "feature_id": "GLYPH_WIDTH_MEAN",
    "value": 17.232142857142858,
    "unit": "px",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 1,
    "formatting_key": "measurement.px",
    "method_id": "component_box_size_v1",
    "quality": {
      "n_observations": 56,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "GLYPH_WIDTH_CV": {
    "feature_id": "GLYPH_WIDTH_CV",
    "value": 0.2789528749360222,
    "unit": "cv",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.cv",
    "method_id": "component_box_size_v1",
    "quality": {
      "n_observations": 56,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "GLYPH_ASPECT_RATIO_MEAN": {
    "feature_id": "GLYPH_ASPECT_RATIO_MEAN",
    "value": 0.881054302155645,
    "unit": "ratio",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.ratio",
    "method_id": "component_box_size_v1",
    "quality": {
      "n_observations": 56,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "GLYPH_ASPECT_RATIO_CV": {
    "feature_id": "GLYPH_ASPECT_RATIO_CV",
    "value": 0.31157217121132835,
    "unit": "cv",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.cv",
    "method_id": "component_box_size_v1",
    "quality": {
      "n_observations": 56,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "SLANT_ANGLE_MEAN": {
    "feature_id": "SLANT_ANGLE_MEAN",
    "value": 20.075050431612258,
    "unit": "degrees",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 1,
    "formatting_key": "measurement.degrees",
    "method_id": "oriented_component_axis_v1",
    "quality": {
      "n_observations": 26,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "SLANT_ANGLE_MEDIAN": {
    "feature_id": "SLANT_ANGLE_MEDIAN",
    "value": 20.71525089687971,
    "unit": "degrees",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 1,
    "formatting_key": "measurement.degrees",
    "method_id": "oriented_component_axis_v1",
    "quality": {
      "n_observations": 26,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "SLANT_ANGLE_STD": {
    "feature_id": "SLANT_ANGLE_STD",
    "value": 9.637173095693731,
    "unit": "degrees",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 1,
    "formatting_key": "measurement.degrees",
    "method_id": "oriented_component_axis_v1",
    "quality": {
      "n_observations": 26,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "SLANT_P05": {
    "feature_id": "SLANT_P05",
    "value": 5.07681240002939,
    "unit": "degrees",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 1,
    "formatting_key": "measurement.degrees",
    "method_id": "oriented_component_axis_v1",
    "quality": {
      "n_observations": 26,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "SLANT_P95": {
    "feature_id": "SLANT_P95",
    "value": 34.60893307811425,
    "unit": "degrees",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 1,
    "formatting_key": "measurement.degrees",
    "method_id": "oriented_component_axis_v1",
    "quality": {
      "n_observations": 26,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "SLANT_LEFT_FRACTION": {
    "feature_id": "SLANT_LEFT_FRACTION",
    "value": 0,
    "unit": "ratio",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.ratio",
    "method_id": "oriented_component_axis_v1",
    "quality": {
      "n_observations": 26,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "SLANT_VERTICAL_FRACTION": {
    "feature_id": "SLANT_VERTICAL_FRACTION",
    "value": 0.038461538461538464,
    "unit": "ratio",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.ratio",
    "method_id": "oriented_component_axis_v1",
    "quality": {
      "n_observations": 26,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "SLANT_RIGHT_FRACTION": {
    "feature_id": "SLANT_RIGHT_FRACTION",
    "value": 0.9615384615384616,
    "unit": "ratio",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.ratio",
    "method_id": "oriented_component_axis_v1",
    "quality": {
      "n_observations": 26,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "SLANT_EXTREME_FRACTION": {
    "feature_id": "SLANT_EXTREME_FRACTION",
    "value": 0.2692307692307692,
    "unit": "ratio",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.ratio",
    "method_id": "oriented_component_axis_v1",
    "quality": {
      "n_observations": 26,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "SLANT_CONSISTENCY": {
    "feature_id": "SLANT_CONSISTENCY",
    "value": 0.8393804484051045,
    "unit": "score_0_1",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.score_0_1",
    "method_id": "oriented_component_axis_v1",
    "quality": {
      "n_observations": 26,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "BASELINE_ANGLE_MEAN": {
    "feature_id": "BASELINE_ANGLE_MEAN",
    "value": -0.41668234220405803,
    "unit": "degrees",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 1,
    "formatting_key": "measurement.degrees",
    "method_id": "bottom_quantile_angle_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "BASELINE_ANGLE_MEDIAN": {
    "feature_id": "BASELINE_ANGLE_MEDIAN",
    "value": -0.30099849734013334,
    "unit": "degrees",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 1,
    "formatting_key": "measurement.degrees",
    "method_id": "bottom_quantile_angle_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "BASELINE_ANGLE_STD": {
    "feature_id": "BASELINE_ANGLE_STD",
    "value": 0.23757000882255241,
    "unit": "degrees",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 1,
    "formatting_key": "measurement.degrees",
    "method_id": "bottom_quantile_angle_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "BASELINE_ABS_SLOPE": {
    "feature_id": "BASELINE_ABS_SLOPE",
    "value": 0.41668234220405803,
    "unit": "degrees",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 1,
    "formatting_key": "measurement.degrees",
    "method_id": "bottom_quantile_angle_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "BASELINE_WAVINESS": {
    "feature_id": "BASELINE_WAVINESS",
    "value": 0.28562284486811274,
    "unit": "normalized",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 3,
    "formatting_key": "measurement.normalized",
    "method_id": "baseline_residual_xheight_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "BASELINE_CURVATURE": {
    "feature_id": "BASELINE_CURVATURE",
    "value": 0.16540083580869946,
    "unit": "normalized",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 3,
    "formatting_key": "measurement.normalized",
    "method_id": "baseline_quadratic_sag_xheight_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "BASELINE_STABILITY": {
    "feature_id": "BASELINE_STABILITY",
    "value": 0.7778330977796106,
    "unit": "score_0_1",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.score_0_1",
    "method_id": "baseline_inverse_waviness_index_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "LINE_SPACING_PX": {
    "feature_id": "LINE_SPACING_PX",
    "value": 47,
    "unit": "px",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 1,
    "formatting_key": "measurement.px",
    "method_id": "accepted_box_gap_px_v1",
    "quality": {
      "n_observations": 2,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "LINE_SPACING_REL": {
    "feature_id": "LINE_SPACING_REL",
    "value": 2.611111111111111,
    "unit": "xheight_ratio",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.xheight_ratio",
    "method_id": "accepted_box_gap_rel_v1",
    "quality": {
      "n_observations": 2,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "LINE_SPACING_CV": {
    "feature_id": "LINE_SPACING_CV",
    "value": 0.02127659574468085,
    "unit": "cv",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.cv",
    "method_id": "accepted_box_gap_cv_v1",
    "quality": {
      "n_observations": 2,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "WORD_SPACING_PX": {
    "feature_id": "WORD_SPACING_PX",
    "value": null,
    "unit": "px",
    "availability": "MISSING",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 1,
    "formatting_key": "measurement.px",
    "method_id": "accepted_box_gap_px_v1",
    "quality": {
      "n_observations": 0,
      "missing_reason": "no_valid_gaps_or_xheight_unavailable",
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "WORD_SPACING_REL": {
    "feature_id": "WORD_SPACING_REL",
    "value": null,
    "unit": "xheight_ratio",
    "availability": "MISSING",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.xheight_ratio",
    "method_id": "accepted_box_gap_rel_v1",
    "quality": {
      "n_observations": 0,
      "missing_reason": "no_valid_gaps_or_xheight_unavailable",
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "WORD_SPACING_CV": {
    "feature_id": "WORD_SPACING_CV",
    "value": null,
    "unit": "cv",
    "availability": "MISSING",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.cv",
    "method_id": "accepted_box_gap_cv_v1",
    "quality": {
      "n_observations": 0,
      "missing_reason": "cv_requires_two_observations_and_positive_mean",
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "MARGIN_TOP_REL": {
    "feature_id": "MARGIN_TOP_REL",
    "value": 3.5555555555555554,
    "unit": "xheight_ratio",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.xheight_ratio",
    "method_id": "text_bounds_xheight_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "MARGIN_BOTTOM_REL": {
    "feature_id": "MARGIN_BOTTOM_REL",
    "value": 3.611111111111111,
    "unit": "xheight_ratio",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.xheight_ratio",
    "method_id": "text_bounds_xheight_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "MARGIN_LEFT_REL": {
    "feature_id": "MARGIN_LEFT_REL",
    "value": 1.7222222222222223,
    "unit": "xheight_ratio",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.xheight_ratio",
    "method_id": "text_bounds_xheight_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "MARGIN_RIGHT_REL": {
    "feature_id": "MARGIN_RIGHT_REL",
    "value": 14.61111111111111,
    "unit": "xheight_ratio",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.xheight_ratio",
    "method_id": "text_bounds_xheight_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "MARGIN_LEFT_VARIABILITY": {
    "feature_id": "MARGIN_LEFT_VARIABILITY",
    "value": 0.015044825131628671,
    "unit": "cv",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.cv",
    "method_id": "line_edge_population_cv_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "MARGIN_RIGHT_VARIABILITY": {
    "feature_id": "MARGIN_RIGHT_VARIABILITY",
    "value": 0.13503817722930328,
    "unit": "cv",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.cv",
    "method_id": "line_edge_population_cv_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "MARGIN_SYMMETRY": {
    "feature_id": "MARGIN_SYMMETRY",
    "value": 0.2108843537414966,
    "unit": "score_0_1",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.score_0_1",
    "method_id": "margin_balance_index_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "TEXT_BLOCK_HORIZONTAL_CENTER": {
    "feature_id": "TEXT_BLOCK_HORIZONTAL_CENTER",
    "value": 0.3373071528751753,
    "unit": "normalized_x",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 3,
    "formatting_key": "measurement.normalized_x",
    "method_id": "text_bounds_canvas_ratio_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "TEXT_BLOCK_VERTICAL_CENTER": {
    "feature_id": "TEXT_BLOCK_VERTICAL_CENTER",
    "value": 0.49841772151898733,
    "unit": "normalized_y",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 3,
    "formatting_key": "measurement.normalized_y",
    "method_id": "text_bounds_canvas_ratio_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "PAGE_HORIZONTAL_DENSITY": {
    "feature_id": "PAGE_HORIZONTAL_DENSITY",
    "value": 0.5876577840112202,
    "unit": "ratio",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.ratio",
    "method_id": "text_bounds_canvas_ratio_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "PAGE_VERTICAL_DENSITY": {
    "feature_id": "PAGE_VERTICAL_DENSITY",
    "value": 0.5917721518987342,
    "unit": "ratio",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.ratio",
    "method_id": "text_bounds_canvas_ratio_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "LINE_LENGTH_MEAN_REL": {
    "feature_id": "LINE_LENGTH_MEAN_REL",
    "value": 0.5053763440860215,
    "unit": "ratio",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.ratio",
    "method_id": "line_width_page_ratio_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "LINE_LENGTH_VARIABILITY": {
    "feature_id": "LINE_LENGTH_VARIABILITY",
    "value": 0.12069940003922362,
    "unit": "cv",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.cv",
    "method_id": "line_edge_population_cv_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "LINE_START_DRIFT": {
    "feature_id": "LINE_START_DRIFT",
    "value": 0.0028349018892692987,
    "unit": "normalized_slope",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 3,
    "formatting_key": "measurement.normalized_slope",
    "method_id": "normalized_edge_vs_vertical_position_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "LINE_END_DRIFT": {
    "feature_id": "LINE_END_DRIFT",
    "value": -0.20254068851278242,
    "unit": "normalized_slope",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 3,
    "formatting_key": "measurement.normalized_slope",
    "method_id": "normalized_edge_vs_vertical_position_v1",
    "quality": {
      "n_observations": 3,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "INK_DARKNESS_MEAN": {
    "feature_id": "INK_DARKNESS_MEAN",
    "value": 0.7882968997084526,
    "unit": "normalized",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 3,
    "formatting_key": "measurement.normalized",
    "method_id": "grayscale_darkness_v1",
    "quality": {
      "n_observations": 9994,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "INK_DARKNESS_STD": {
    "feature_id": "INK_DARKNESS_STD",
    "value": 0.15468451239905937,
    "unit": "normalized",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 3,
    "formatting_key": "measurement.normalized",
    "method_id": "grayscale_darkness_v1",
    "quality": {
      "n_observations": 9994,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "INK_DARKNESS_CV": {
    "feature_id": "INK_DARKNESS_CV",
    "value": 0.1962262092572844,
    "unit": "cv",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.cv",
    "method_id": "grayscale_darkness_v1",
    "quality": {
      "n_observations": 9994,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "STROKE_WIDTH_MEAN": {
    "feature_id": "STROKE_WIDTH_MEAN",
    "value": 4.3125289637480755,
    "unit": "px",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 1,
    "formatting_key": "measurement.px",
    "method_id": "medial_axis_diameter_v1",
    "quality": {
      "n_observations": 2300,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "STROKE_WIDTH_MEDIAN": {
    "feature_id": "STROKE_WIDTH_MEDIAN",
    "value": 4.47213595499958,
    "unit": "px",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 1,
    "formatting_key": "measurement.px",
    "method_id": "medial_axis_diameter_v1",
    "quality": {
      "n_observations": 2300,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "STROKE_WIDTH_STD": {
    "feature_id": "STROKE_WIDTH_STD",
    "value": 0.9931977461316084,
    "unit": "px",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 1,
    "formatting_key": "measurement.px",
    "method_id": "medial_axis_diameter_v1",
    "quality": {
      "n_observations": 2300,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "STROKE_WIDTH_CV": {
    "feature_id": "STROKE_WIDTH_CV",
    "value": 0.23030517695779304,
    "unit": "cv",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.cv",
    "method_id": "medial_axis_diameter_v1",
    "quality": {
      "n_observations": 2300,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "STROKE_UNIFORMITY": {
    "feature_id": "STROKE_UNIFORMITY",
    "value": 0.8128064635741235,
    "unit": "score_0_1",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.score_0_1",
    "method_id": "medial_axis_diameter_v1",
    "quality": {
      "n_observations": 2300,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  },
  "INK_SATURATION_FRACTION": {
    "feature_id": "INK_SATURATION_FRACTION",
    "value": 0.0015009005403241946,
    "unit": "ratio",
    "availability": "UNCALIBRATED",
    "evidence_class": "COMPUTATIONAL_PROXY",
    "precision": 2,
    "formatting_key": "measurement.ratio",
    "method_id": "grayscale_darkness_v1",
    "quality": {
      "n_observations": 9994,
      "missing_reason": null,
      "confidence_kind": "UNCALIBRATED"
    }
  }
};
Object.assign(__ds_scope, { SampleEvidence, SampleFacts });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/charts/sampleEvidence.js", error: String((e && e.message) || e) }); }

// components/charts/HandwritingCanvas.jsx
try { (() => {
const S = v => ({
  stroke: v,
  vectorEffect: "non-scaling-stroke"
});
const avgY = p => p.reduce((s, q) => s + q[1], 0) / p.length;
const LAYERS = ["baseline", "slant", "spacing", "margins", "xheight", "lines", "components"];
function Plate({
  ev,
  layers,
  labels,
  glyphs,
  fontSize
}) {
  const {
      w: W,
      h: H
    } = ev.frame,
    A = "var(--plate-annotation)",
    A2 = "var(--plate-annotation-2)",
    M = "var(--plate-muted)",
    R = "var(--plate-rejected)";
  const right = Math.max(...ev.lines.map(l => l[0] + l[2]));
  const left = Math.min(...ev.lines.map(l => l[0]));
  const lab = (x, y, t, c = A, anchor = "start") => labels && /*#__PURE__*/React.createElement("text", {
    x: x,
    y: y,
    fontFamily: "var(--font-mono)",
    fontSize: "10",
    fill: c,
    textAnchor: anchor,
    letterSpacing: ".04em"
  }, t);
  const on = k => layers.includes(k);
  const b0 = avgY(ev.baselines[0]);
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${W} ${H}`,
    width: "100%",
    style: {
      display: "block",
      overflow: "visible"
    },
    "aria-hidden": "true"
  }, on("margins") && /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("rect", {
    x: "0",
    y: "0",
    width: left,
    height: H,
    fill: A2,
    opacity: ".08"
  }), /*#__PURE__*/React.createElement("rect", {
    x: right,
    y: "0",
    width: W - right,
    height: H,
    fill: A2,
    opacity: ".08"
  }), [left, right].map(x => /*#__PURE__*/React.createElement("line", {
    key: x,
    x1: x,
    y1: "0",
    x2: x,
    y2: H,
    style: S(A2),
    strokeDasharray: "3 3"
  })), lab(right + 10, 22, "RIGHT MARGIN", A2), lab(left + 6, H - 10, "LEFT", A2)), glyphs && /*#__PURE__*/React.createElement("g", {
    fill: "var(--plate-ink)"
  }, ev.lines.map((l, i) => /*#__PURE__*/React.createElement("text", {
    key: i,
    x: l[0],
    y: avgY(ev.baselines[i]) + 1,
    fontFamily: "var(--font-specimen)",
    fontSize: fontSize,
    textLength: l[2],
    lengthAdjust: "spacingAndGlyphs"
  }, ev.glyphText?.[i] ?? ""))), on("lines") && /*#__PURE__*/React.createElement("g", null, ev.lines.map((l, i) => /*#__PURE__*/React.createElement("g", {
    key: i
  }, /*#__PURE__*/React.createElement("rect", {
    x: l[0],
    y: l[1],
    width: l[2],
    height: l[3],
    fill: "none",
    style: S(M),
    strokeDasharray: "2 3"
  }), lab(l[0] + l[2] + 6, l[1] + 10, "line_" + i, M)))), on("components") && /*#__PURE__*/React.createElement("g", null, ev.components.map((k, i) => /*#__PURE__*/React.createElement("rect", {
    key: i,
    x: k[0],
    y: k[1],
    width: k[2],
    height: k[3],
    fill: "none",
    style: S(M),
    strokeWidth: ".75"
  }))), on("xheight") && /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("rect", {
    x: ev.lines[0][0],
    y: b0 - ev.xHeight,
    width: ev.lines[0][2],
    height: ev.xHeight,
    fill: A,
    opacity: ".1"
  }), [b0 - ev.xHeight, b0].map(y => /*#__PURE__*/React.createElement("line", {
    key: y,
    x1: ev.lines[0][0] - 8,
    y1: y,
    x2: ev.lines[0][0] + ev.lines[0][2],
    y2: y,
    style: S(A)
  })), lab(ev.lines[0][0] + ev.lines[0][2] + 6, b0 - 5, `x-height ${ev.xHeight} px`)), on("baseline") && /*#__PURE__*/React.createElement("g", null, ev.baselines.map((p, i) => /*#__PURE__*/React.createElement("g", {
    key: i
  }, /*#__PURE__*/React.createElement("polyline", {
    points: p.map(q => q.join(",")).join(" "),
    fill: "none",
    style: S(A),
    strokeWidth: "1.25",
    strokeLinejoin: "round"
  }), p.map((q, j) => /*#__PURE__*/React.createElement("circle", {
    key: j,
    cx: q[0],
    cy: q[1],
    r: "2",
    fill: A
  })), ev.baselineAngles && lab(p[p.length - 1][0] + 8, p[p.length - 1][1] + 4, new Intl.NumberFormat("en-GB", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(ev.baselineAngles[i]) + "°")))), on("slant") && /*#__PURE__*/React.createElement("g", null, ev.components.map((k, i) => {
    if (k[4] === null) return null;
    const cx = k[0] + k[2] / 2,
      cy = k[1] + k[3] / 2,
      len = Math.max(k[3], 16) * 1.1,
      a = k[4] * Math.PI / 180,
      dx = Math.sin(a) * len / 2,
      dy = Math.cos(a) * len / 2;
    return /*#__PURE__*/React.createElement("line", {
      key: i,
      x1: cx - dx,
      y1: cy + dy,
      x2: cx + dx,
      y2: cy - dy,
      style: S(k[5] ? A : R),
      strokeWidth: k[5] ? 1.5 : 1,
      strokeDasharray: k[5] ? undefined : "2 2",
      strokeLinecap: "round"
    });
  })), on("spacing") && /*#__PURE__*/React.createElement("g", null, ev.lines.slice(0, -1).map((l, i) => {
    const y1 = l[1] + l[3],
      y2 = ev.lines[i + 1][1],
      bx = left - 14;
    return /*#__PURE__*/React.createElement("g", {
      key: i
    }, /*#__PURE__*/React.createElement("path", {
      d: `M${bx + 5},${y1} H${bx} V${y2} H${bx + 5}`,
      fill: "none",
      style: S(A),
      strokeWidth: "1.25"
    }), lab(bx - 6, (y1 + y2) / 2 + 4, (ev.lineGaps?.[i] ?? "") + " px", A, "end"));
  })));
}
function HandwritingCanvas({
  evidence,
  layers = ["baseline", "spacing"],
  loupe = true,
  labels = true,
  glyphs = true,
  fontSize = 38,
  zoom = 2.6,
  caption,
  illustrativeNote = "Synthetic sample · glyphs illustrative",
  onInspect
}) {
  const ev = evidence,
    ref = React.useRef(null);
  const [pt, setPt] = React.useState(null);
  const [w, setW] = React.useState(0);
  const obs = React.useMemo(() => ev.components.map((k, i) => ({
    i,
    k
  })).filter(o => o.k[4] !== null), [ev]);
  const [kb, setKb] = React.useState(-1);
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setW(el.offsetWidth));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  const nearest = (fx, fy) => {
    let best = null,
      bd = 1e9;
    obs.forEach(o => {
      const d = Math.hypot(o.k[0] + o.k[2] / 2 - fx, o.k[1] + o.k[3] / 2 - fy);
      if (d < bd) {
        bd = d;
        best = o;
      }
    });
    return bd < 30 ? best : null;
  };
  const place = (x, y) => {
    const s = w / ev.frame.w,
      hit = nearest(x / s, y / s);
    setPt({
      x,
      y,
      hit
    });
    onInspect && onInspect(hit ? {
      component: hit.i,
      slant: hit.k[4],
      accepted: !!hit.k[5]
    } : null);
  };
  const move = e => {
    if (!loupe) return;
    const r = ref.current.getBoundingClientRect();
    const x = e.clientX - r.left,
      y = e.clientY - r.top;
    if (x < 0 || y < 0 || x > r.width || y > r.height) {
      setPt(null);
      return;
    }
    place(x, y);
  };
  const key = e => {
    if (!loupe || !["ArrowRight", "ArrowLeft", "Escape"].includes(e.key)) return;
    e.preventDefault();
    if (e.key === "Escape") {
      setPt(null);
      setKb(-1);
      return;
    }
    const n = (kb + (e.key === "ArrowRight" ? 1 : -1) + obs.length) % obs.length;
    setKb(n);
    const k = obs[n].k,
      s = w / ev.frame.w;
    place((k[0] + k[2] / 2) * s, (k[1] + k[3] / 2) * s);
  };
  const fmt = v => new Intl.NumberFormat("en-GB", {
    maximumFractionDigits: 1,
    minimumFractionDigits: 1
  }).format(v);
  const L = 180;
  return /*#__PURE__*/React.createElement("figure", {
    style: {
      margin: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ik-plate",
    style: {
      padding: "30px 34px 30px 48px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    ref: ref,
    style: {
      position: "relative",
      cursor: loupe ? "crosshair" : undefined,
      outlineOffset: 6
    },
    tabIndex: loupe ? 0 : undefined,
    role: "img",
    "aria-label": `Annotated handwriting sample. Layers shown: ${layers.join(", ")}.${loupe ? " Use left and right arrow keys to inspect each slant observation." : ""}`,
    onMouseMove: move,
    onMouseLeave: () => setPt(null),
    onKeyDown: key,
    onBlur: () => {
      setPt(null);
      setKb(-1);
    }
  }, /*#__PURE__*/React.createElement(Plate, {
    ev: ev,
    layers: layers,
    labels: labels,
    glyphs: glyphs,
    fontSize: fontSize
  }), loupe && pt && w > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "ik-loupe",
    style: {
      left: pt.x - L / 2,
      top: pt.y - L / 2,
      width: L,
      height: L
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      width: w * zoom,
      left: L / 2 - pt.x * zoom,
      top: L / 2 - pt.y * zoom
    }
  }, /*#__PURE__*/React.createElement(Plate, {
    ev: ev,
    layers: layers,
    labels: false,
    glyphs: glyphs,
    fontSize: fontSize
  }))), /*#__PURE__*/React.createElement("div", {
    className: "ik-loupe-read",
    style: {
      left: pt.x + L / 2 + 8,
      top: pt.y - 12
    },
    "aria-live": "polite"
  }, pt.hit ? `Slant ${fmt(pt.hit.k[4])}° · ${pt.hit.k[5] ? "accepted" : "rejected"}` : "No observation here"))), illustrativeNote && /*#__PURE__*/React.createElement("div", {
    className: "ik-cap",
    style: {
      position: "absolute",
      right: 12,
      bottom: 8,
      fontSize: 10
    }
  }, illustrativeNote)), caption && /*#__PURE__*/React.createElement("figcaption", {
    className: "ik-figcap"
  }, caption));
}
HandwritingCanvas.LAYERS = LAYERS;
Object.assign(__ds_scope, { SampleEvidence: __ds_scope.SampleEvidence, SampleFacts: __ds_scope.SampleFacts, HandwritingCanvas });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/charts/HandwritingCanvas.jsx", error: String((e && e.message) || e) }); }

// components/evidence/messages.js
try { (() => {
// Display strings (EN/SV), ported from packages/report-web/src/messages.ts. Keys unchanged.
// Entries marked DRAFT have no string in the repo yet.
const EN = {
  "availability.READY": "Measured",
  "availability.UNCALIBRATED": "Not calibrated",
  "availability.MISSING": "Not measured in this sample",
  "availability.NOT_IMPLEMENTED": "Not available yet",
  "availability.INELIGIBLE": "Not applicable to this sample",
  "availability.LOCKED": "Available with Premium",
  "availability.PENDING": "In progress",
  "availability.FAILED": "Could not be produced",
  "availability.REVOKED": "No longer available",
  "evidence.MEASURED": "Measured",
  "evidence.COMPUTATIONAL_PROXY": "Computed proxy",
  "evidence.REFERENCE_STATISTIC": "Reference statistic",
  "evidence.AUTHORED_CONTENT": "Authored",
  "evidence.TRADITIONAL_ASSOCIATION": "Traditional graphology",
  "evidence.AI_SYNTHESIS": "AI-assisted",
  "notice.measured": "Measured values come directly from your handwriting image.",
  "notice.proxy_uncalibrated": "Computed proxies are engineering indices. They are not calibrated and are not percentiles.",
  "notice.reference_unavailable": "No reference group is available yet, so nothing here is ranked against other writers.",
  "notice.reference_named_cohort": "Comparisons use the named reference group shown next to each rank.",
  "notice.traditional_not_included": "Traditional graphology interpretations are not included.",
  "notice.ai_synthesis": "AI-assisted sections explain measured facts; they do not change them.",
  "notice.private_report": "This report is private to your account.",
  "notice.source_image_omitted": "Source image omitted.",
  "action.COMPARE": "Compare",
  "action.EXPORT": "Export PDF",
  "action.SHARE": "Share",
  "action.SAVE": "Save",
  "action.DELETE": "Delete",
  "action.PURCHASE": "Get Premium",
  "reason.commerce_disabled": "Purchases are not available yet.",
  "reason.sharing_disabled": "Sharing is not available yet.",
  "reason.comparison_not_available": "Comparison is not available yet.",
  "reason.sharing_not_available": "Share links are not available yet.",
  "reason.save_not_available": "Reports are saved to your account automatically.",
  "reason.delete_from_settings": "Delete the sample in Settings to remove this report.",
  "reason.export_not_available": "PDF export is not available yet.",
  "reason.premium_not_yet_available": "Premium isn't available yet.",
  /* DRAFT */
  "quality.observations": "observations",
  "quality.exact": "Exact for this image",
  "quality.uncalibrated": "Not calibrated",
  "evidence.title": "Evidence behind the measurements",
  "evidence.accepted": "Accepted",
  "evidence.rejected": "Rejected",
  "value.yes": "Yes",
  "value.no": "No",
  "job.QUEUED": "Waiting to start",
  "job.RUNNING": "Measuring your handwriting",
  "job.SUCCEEDED": "Your report is ready",
  "job.FAILED": "The analysis could not finish",
  "job.CANCELLED": "Analysis cancelled",
  "illustrative": "Illustrative"
};
const SV = {
  "availability.READY": "Uppmätt",
  "availability.UNCALIBRATED": "Inte kalibrerad",
  "availability.MISSING": "Inte uppmätt i detta prov",
  "availability.NOT_IMPLEMENTED": "Inte tillgänglig ännu",
  "availability.INELIGIBLE": "Gäller inte detta prov",
  "availability.LOCKED": "Ingår i Premium",
  "availability.PENDING": "Pågår",
  "availability.FAILED": "Kunde inte tas fram",
  "availability.REVOKED": "Inte längre tillgänglig",
  "evidence.MEASURED": "Uppmätt",
  "evidence.COMPUTATIONAL_PROXY": "Beräknat närmevärde",
  "evidence.REFERENCE_STATISTIC": "Referensstatistik",
  "evidence.AUTHORED_CONTENT": "Redaktionellt",
  "evidence.TRADITIONAL_ASSOCIATION": "Traditionell grafologi",
  "evidence.AI_SYNTHESIS": "AI-stött",
  "notice.measured": "Uppmätta värden kommer direkt från bilden av din handstil.",
  "notice.proxy_uncalibrated": "Beräknade närmevärden är tekniska index. De är inte kalibrerade och är inte percentiler.",
  "notice.reference_unavailable": "Det finns ännu ingen referensgrupp, så inget här rangordnas mot andra skribenter.",
  "notice.reference_named_cohort": "Jämförelser använder den namngivna referensgruppen som visas vid varje rang.",
  "notice.traditional_not_included": "Traditionella grafologiska tolkningar ingår inte.",
  "notice.ai_synthesis": "AI-stödda avsnitt förklarar uppmätta fakta; de ändrar dem inte.",
  "notice.private_report": "Den här rapporten är privat för ditt konto.",
  "notice.source_image_omitted": "Källbilden är utelämnad.",
  "action.COMPARE": "Jämför",
  "action.EXPORT": "Exportera PDF",
  "action.SHARE": "Dela",
  "action.SAVE": "Spara",
  "action.DELETE": "Radera",
  "action.PURCHASE": "Skaffa Premium",
  "reason.commerce_disabled": "Köp är inte tillgängliga ännu.",
  "reason.sharing_disabled": "Delning är inte tillgänglig ännu.",
  "reason.comparison_not_available": "Jämförelse är inte tillgänglig ännu.",
  "reason.export_not_available": "PDF-export är inte tillgänglig ännu.",
  "reason.premium_not_yet_available": "Premium är inte tillgängligt ännu.",
  "quality.observations": "observationer",
  "quality.exact": "Exakt för denna bild",
  "quality.uncalibrated": "Inte kalibrerad",
  "evidence.title": "Underlag bakom mätvärdena",
  "evidence.accepted": "Godkänd",
  "evidence.rejected": "Underkänd",
  "value.yes": "Ja",
  "value.no": "Nej",
  "job.QUEUED": "Väntar på att starta",
  "job.RUNNING": "Din handstil mäts",
  "job.SUCCEEDED": "Din rapport är klar",
  "job.FAILED": "Analysen kunde inte slutföras",
  "job.CANCELLED": "Analysen avbröts",
  "illustrative": "Illustrativ"
};
const CATALOGS = {
  en: EN,
  sv: SV
};
function t(locale, key) {
  return (CATALOGS[locale] || EN)[key] ?? EN[key] ?? key;
}
const EVIDENCE_GLYPH = {
  MEASURED: "◆",
  COMPUTATIONAL_PROXY: "◇",
  REFERENCE_STATISTIC: "▲",
  AUTHORED_CONTENT: "✎",
  TRADITIONAL_ASSOCIATION: "☾",
  AI_SYNTHESIS: "✦"
};
const SUFFIX = {
  "measurement.px": " px",
  "measurement.degrees": "°",
  "measurement.MP": " MP"
};
// Port of packages/report-core/src/format.ts formatFact.
function formatFact(fact, locale) {
  const present = fact.availability === "READY" || fact.availability === "UNCALIBRATED";
  if (!present || fact.value === null || fact.value === undefined) return {
    state: "UNAVAILABLE",
    availability: fact.availability,
    reasonKey: "availability." + fact.availability
  };
  const calibrated = fact.availability === "READY";
  const v = fact.value;
  if (typeof v === "number") {
    const digits = fact.precision ?? 2;
    let text = new Intl.NumberFormat(locale === "sv" ? "sv-SE" : "en-GB", {
      minimumFractionDigits: digits,
      maximumFractionDigits: digits
    }).format(v);
    if (/^[-−]0([.,]0+)?$/.test(text)) text = text.replace(/^[-−]/, "");
    return {
      state: "VALUE",
      text,
      suffix: SUFFIX[fact.formatting_key] ?? "",
      calibrated
    };
  }
  if (typeof v === "boolean") return {
    state: "VALUE",
    text: t(locale, v ? "value.yes" : "value.no"),
    suffix: "",
    calibrated
  };
  return {
    state: "VALUE",
    text: String(v),
    suffix: "",
    calibrated
  };
}
Object.assign(__ds_scope, { t, EVIDENCE_GLYPH, formatFact });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/evidence/messages.js", error: String((e && e.message) || e) }); }

// components/evidence/EvidenceBadge.jsx
try { (() => {
function EvidenceBadge({
  evidence,
  locale = "en",
  size = "md",
  suffix
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: `ik-badge ik-ev-${evidence}${size === "lg" ? " ik-badge--lg" : ""}`,
    "data-evidence": evidence
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true"
  }, __ds_scope.EVIDENCE_GLYPH[evidence]), /*#__PURE__*/React.createElement("span", null, __ds_scope.t(locale, `evidence.${evidence}`), suffix ? ` · ${suffix}` : ""));
}
Object.assign(__ds_scope, { EvidenceBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/evidence/EvidenceBadge.jsx", error: String((e && e.message) || e) }); }

// components/evidence/FactValue.jsx
try { (() => {
function FactValue({
  fact,
  locale = "en",
  size = "md",
  showCalibration = true
}) {
  const f = __ds_scope.formatFact(fact, locale);
  if (f.state === "UNAVAILABLE") {
    const hatch = fact.availability === "MISSING" || fact.availability === "FAILED" || fact.availability === "REVOKED";
    return /*#__PURE__*/React.createElement("span", {
      className: "ik-unavailable",
      "data-availability": fact.availability
    }, hatch && /*#__PURE__*/React.createElement("span", {
      className: "ik-hatch ik-unavailable__mark",
      "aria-hidden": "true"
    }), fact.availability === "LOCKED" && /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true"
    }, "\u2302"), /*#__PURE__*/React.createElement("span", null, __ds_scope.t(locale, f.reasonKey)));
  }
  const cls = `ik-value${size !== "md" ? ` ik-value--${size}` : ""}`;
  const unitIsWord = !f.suffix && fact.unit && !["count", "ratio"].includes(fact.unit);
  return /*#__PURE__*/React.createElement("span", {
    "data-availability": fact.availability
  }, /*#__PURE__*/React.createElement("span", {
    className: cls
  }, f.text, f.suffix === "°" ? "°" : f.suffix ? /*#__PURE__*/React.createElement("span", {
    className: "ik-value__unit"
  }, f.suffix.trim()) : null, unitIsWord && /*#__PURE__*/React.createElement("span", {
    className: "ik-value__unit"
  }, fact.unit === "score_0_1" ? "/ 0–1 index" : fact.unit === "xheight_ratio" ? "× x-height" : fact.unit)), showCalibration && !f.calibrated && /*#__PURE__*/React.createElement("span", {
    className: "ik-uncal"
  }, __ds_scope.t(locale, "availability.UNCALIBRATED")));
}
Object.assign(__ds_scope, { FactValue });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/evidence/FactValue.jsx", error: String((e && e.message) || e) }); }

// components/evidence/NoticeBar.jsx
try { (() => {
const GLYPH = {
  "notice.measured": "◆",
  "notice.proxy_uncalibrated": "◇",
  "notice.reference_unavailable": "▲",
  "notice.reference_named_cohort": "▲",
  "notice.traditional_not_included": "☾",
  "notice.ai_synthesis": "✦",
  "notice.private_report": "⌂",
  "notice.source_image_omitted": "▢"
};
function NoticeBar({
  notices,
  locale = "en",
  label = "Notices"
}) {
  return /*#__PURE__*/React.createElement("ul", {
    className: "ik-notices",
    "aria-label": label
  }, notices.map(n => {
    const key = typeof n === "string" ? n : n.localization_key;
    return /*#__PURE__*/React.createElement("li", {
      key: key,
      "data-notice": key
    }, /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true"
    }, GLYPH[key] ?? "·"), /*#__PURE__*/React.createElement("span", null, __ds_scope.t(locale, key)));
  }));
}
Object.assign(__ds_scope, { NoticeBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/evidence/NoticeBar.jsx", error: String((e && e.message) || e) }); }

// components/evidence/QualityHint.jsx
try { (() => {
function QualityHint({
  quality,
  availability,
  method,
  locale = "en"
}) {
  const n = quality?.n_observations ?? 0;
  const parts = [`n = ${n} ${__ds_scope.t(locale, "quality.observations")}`];
  if (quality?.confidence_kind === "EXACT_CONDITIONAL") parts.push(__ds_scope.t(locale, "quality.exact"));else if (availability === "UNCALIBRATED" || quality?.confidence_kind === "UNCALIBRATED") parts.push(__ds_scope.t(locale, "quality.uncalibrated"));
  if (quality?.missing_reason) parts.push(quality.missing_reason.replace(/_/g, " "));
  if (method) parts.push(method);
  return /*#__PURE__*/React.createElement("span", {
    className: "ik-cap",
    style: {
      textTransform: "none",
      letterSpacing: 0,
      fontSize: "var(--font-size-xs)"
    }
  }, parts.join(" · "));
}
Object.assign(__ds_scope, { QualityHint });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/evidence/QualityHint.jsx", error: String((e && e.message) || e) }); }

// components/flow/ConsentChoice.jsx
try { (() => {
function ConsentChoice({
  id,
  title,
  description,
  required = false,
  checked,
  onChange,
  disabled = false,
  note
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: "ik-choice",
    htmlFor: id
  }, /*#__PURE__*/React.createElement("input", {
    id: id,
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: e => onChange && onChange(e.currentTarget.checked),
    "aria-describedby": id + "-d"
  }), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      gap: 10,
      alignItems: "baseline",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "500 17px/1.35 var(--font-serif)"
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    className: "ik-cap",
    style: {
      color: required ? "var(--text-accent)" : "var(--text-muted)"
    }
  }, required ? "Needed for the report" : "Optional")), /*#__PURE__*/React.createElement("span", {
    id: id + "-d",
    className: "ik-hint",
    style: {
      display: "block",
      marginTop: 4,
      fontSize: 15
    }
  }, description), note && /*#__PURE__*/React.createElement("span", {
    className: "ik-cap",
    style: {
      display: "block",
      marginTop: 8,
      textTransform: "none",
      letterSpacing: 0
    }
  }, note)));
}
Object.assign(__ds_scope, { ConsentChoice });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/flow/ConsentChoice.jsx", error: String((e && e.message) || e) }); }

// components/flow/CreditBalance.jsx
try { (() => {
function CreditBalance({
  available = null,
  reserved = 0,
  platform = "Web",
  note
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 32,
      alignItems: "flex-end",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ik-value"
  }, available === null ? /*#__PURE__*/React.createElement("em", {
    className: "ik-hint"
  }, "Unavailable") : available), /*#__PURE__*/React.createElement("div", {
    className: "ik-cap",
    style: {
      marginTop: 6
    }
  }, "Premium credits \xB7 ", platform)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ik-value ik-value--sm",
    style: {
      color: "var(--text-muted)"
    }
  }, reserved), /*#__PURE__*/React.createElement("div", {
    className: "ik-cap",
    style: {
      marginTop: 6
    }
  }, "Reserved")), note && /*#__PURE__*/React.createElement("p", {
    className: "ik-hint",
    style: {
      margin: 0,
      maxWidth: 280
    }
  }, note));
}
Object.assign(__ds_scope, { CreditBalance });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/flow/CreditBalance.jsx", error: String((e && e.message) || e) }); }

// components/flow/JobStatus.jsx
try { (() => {
const COLOR = {
  QUEUED: "var(--state-info)",
  RUNNING: "var(--state-info)",
  SUCCEEDED: "var(--state-ready)",
  FAILED: "var(--state-danger)",
  CANCELLED: "var(--state-locked)"
};
const GLYPH = {
  QUEUED: "○",
  RUNNING: "◌",
  SUCCEEDED: "●",
  FAILED: "!",
  CANCELLED: "–"
};
function JobStatus({
  status,
  steps,
  detail,
  errorCode,
  locale = "en",
  title
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "ik-status",
    role: "status",
    "aria-live": "polite",
    "data-status": status
  }, /*#__PURE__*/React.createElement("span", {
    className: "ik-status__dot",
    style: {
      color: COLOR[status],
      background: status === "SUCCEEDED" ? COLOR[status] : "transparent"
    },
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "italic 300 var(--font-size-3xl)/1.1 var(--font-serif)",
      letterSpacing: "-.015em"
    }
  }, title ?? __ds_scope.t(locale, `job.${status}`)), detail && /*#__PURE__*/React.createElement("p", {
    className: "ik-hint",
    style: {
      margin: "8px 0 0"
    }
  }, detail), errorCode && /*#__PURE__*/React.createElement("p", {
    className: "ik-cap",
    style: {
      color: "var(--state-danger)",
      margin: "10px 0 0"
    }
  }, GLYPH.FAILED, " ", errorCode), steps && /*#__PURE__*/React.createElement("ol", {
    style: {
      listStyle: "none",
      padding: 0,
      margin: "20px 0 0",
      display: "grid",
      gap: 0
    }
  }, steps.map((s, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      display: "grid",
      gridTemplateColumns: "20px 1fr",
      gap: 10,
      padding: "9px 0",
      borderTop: "1px solid var(--border-hairline)",
      color: s.state === "done" ? "var(--text-body)" : "var(--text-muted)",
      font: "400 15px var(--font-serif)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ik-cap",
    style: {
      color: s.state === "done" ? "var(--state-ready)" : s.state === "active" ? "var(--state-info)" : "var(--text-muted)"
    },
    "aria-hidden": "true"
  }, s.state === "done" ? "✓" : s.state === "active" ? "◌" : "○"), /*#__PURE__*/React.createElement("span", null, s.label, s.state === "active" && /*#__PURE__*/React.createElement("span", {
    className: "ik-visually-hidden"
  }, " (in progress)")))))));
}
Object.assign(__ds_scope, { JobStatus });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/flow/JobStatus.jsx", error: String((e && e.message) || e) }); }

// components/flow/UploadField.jsx
try { (() => {
function UploadField({
  fileName,
  error,
  disabled = false,
  onPick,
  accept = "image/jpeg,image/png",
  hint = "JPEG or PNG, up to 20 MB. One page of your own handwriting."
}) {
  const ref = React.useRef(null);
  const [over, setOver] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("button", {
    type: "button",
    disabled: disabled,
    onClick: () => ref.current && ref.current.click(),
    onDragOver: e => {
      e.preventDefault();
      setOver(true);
    },
    onDragLeave: () => setOver(false),
    onDrop: e => {
      e.preventDefault();
      setOver(false);
      const f = e.dataTransfer.files[0];
      if (f && onPick) onPick(f);
    },
    style: {
      width: "100%",
      minHeight: 220,
      display: "grid",
      placeItems: "center",
      gap: 10,
      padding: 32,
      cursor: disabled ? "not-allowed" : "pointer",
      background: over ? "var(--surface-card)" : "var(--surface-plate)",
      border: `1.5px dashed ${error ? "var(--state-danger)" : over ? "var(--pencil)" : "var(--rule-strong)"}`,
      color: "var(--text-body)",
      font: "inherit"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "grid",
      gap: 8,
      justifyItems: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "italic 300 var(--font-size-2xl)/1.2 var(--font-serif)"
    }
  }, fileName ? fileName : "Choose a photo of your handwriting"), /*#__PURE__*/React.createElement("span", {
    className: "ik-cap"
  }, fileName ? "Choose a different photo" : "or drop it here · or take a photo"))), /*#__PURE__*/React.createElement("input", {
    ref: ref,
    type: "file",
    accept: accept,
    hidden: true,
    onChange: e => {
      const f = e.currentTarget.files && e.currentTarget.files[0];
      if (f && onPick) onPick(f);
    }
  }), error ? /*#__PURE__*/React.createElement("p", {
    role: "alert",
    className: "ik-hint",
    style: {
      color: "var(--state-danger)",
      margin: "10px 0 0"
    }
  }, error) : /*#__PURE__*/React.createElement("p", {
    className: "ik-hint",
    style: {
      margin: "10px 0 0"
    }
  }, hint));
}
Object.assign(__ds_scope, { UploadField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/flow/UploadField.jsx", error: String((e && e.message) || e) }); }

// components/report/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Button({
  variant = "primary",
  block = false,
  disabled = false,
  reason,
  type = "button",
  onClick,
  children,
  ...rest
}) {
  const id = React.useId ? React.useId() : undefined;
  const btn = /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    className: `ik-btn${variant !== "primary" ? ` ik-btn--${variant}` : ""}${block ? " ik-btn--block" : ""}`,
    disabled: disabled,
    "aria-describedby": reason ? id : undefined,
    onClick: disabled ? undefined : onClick
  }, rest), children);
  if (!reason) return btn;
  return /*#__PURE__*/React.createElement("span", {
    className: "ik-action"
  }, btn, /*#__PURE__*/React.createElement("span", {
    id: id,
    className: "ik-hint",
    style: {
      fontSize: "var(--font-size-xs)"
    }
  }, reason));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/report/Button.jsx", error: String((e && e.message) || e) }); }

// components/report/ActionBar.jsx
try { (() => {
function ActionBar({
  actions,
  locale = "en",
  onAction,
  primary = "COMPARE"
}) {
  const order = ["COMPARE", "SHARE", "EXPORT", "SAVE", "PURCHASE", "DELETE"];
  const list = [...actions].sort((a, b) => order.indexOf(a.kind) - order.indexOf(b.kind));
  return /*#__PURE__*/React.createElement("div", {
    className: "ik-actions",
    role: "group",
    "aria-label": "Report actions"
  }, list.map(a => /*#__PURE__*/React.createElement(__ds_scope.Button, {
    key: a.kind,
    variant: a.kind === primary ? "primary" : a.kind === "DELETE" ? "ghost" : "secondary",
    disabled: !a.enabled,
    reason: a.reason ? __ds_scope.t(locale, `reason.${a.reason}`) : undefined,
    onClick: () => onAction && onAction(a.kind)
  }, __ds_scope.t(locale, `action.${a.kind}`))));
}
Object.assign(__ds_scope, { ActionBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/report/ActionBar.jsx", error: String((e && e.message) || e) }); }

// components/report/MarginNote.jsx
try { (() => {
function MarginNote({
  index,
  label,
  value,
  children,
  active = false,
  unavailable = false,
  onSelect
}) {
  const body = /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "ik-note__num",
    "aria-hidden": "true"
  }, index), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ik-cap",
    style: {
      display: "block"
    }
  }, label), unavailable ? /*#__PURE__*/React.createElement("span", {
    className: "ik-hatch",
    style: {
      display: "block",
      height: 24,
      margin: "8px 0"
    },
    "aria-hidden": "true"
  }) : value && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      margin: "4px 0"
    }
  }, value), /*#__PURE__*/React.createElement("span", {
    className: "ik-note__body",
    style: {
      display: "block",
      fontStyle: unavailable ? "italic" : undefined,
      color: unavailable ? "var(--text-body)" : undefined
    }
  }, children)));
  if (unavailable || !onSelect) return /*#__PURE__*/React.createElement("div", {
    className: `ik-note${unavailable ? " ik-note--unavailable" : ""}`
  }, body);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "ik-note",
    "aria-pressed": active,
    onClick: onSelect
  }, body);
}
Object.assign(__ds_scope, { MarginNote });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/report/MarginNote.jsx", error: String((e && e.message) || e) }); }

// components/report/ReportSection.jsx
try { (() => {
function ReportSection({
  kicker,
  title,
  availability,
  aside,
  children,
  id,
  divider = true
}) {
  const hid = id ? id + "-title" : undefined;
  return /*#__PURE__*/React.createElement("section", {
    className: "ik-section",
    style: divider ? undefined : {
      borderTop: 0
    },
    "aria-labelledby": hid,
    "data-availability": availability
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-end",
      gap: 24,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, kicker && /*#__PURE__*/React.createElement("div", {
    className: "ik-cap ik-cap--accent"
  }, kicker), title && /*#__PURE__*/React.createElement("h2", {
    id: hid,
    className: "ik-section__title"
  }, title)), aside), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: title ? 28 : 12
    }
  }, children));
}
Object.assign(__ds_scope, { ReportSection });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/report/ReportSection.jsx", error: String((e && e.message) || e) }); }

// components/report/Standout.jsx
try { (() => {
function Standout({
  kicker = "What stands out",
  statement,
  lede,
  facts = [],
  evidence,
  evidenceSuffix,
  illustrative = true,
  size = "lg"
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ik-cap ik-cap--accent"
  }, kicker), illustrative && /*#__PURE__*/React.createElement("span", {
    className: "ik-illustrative",
    title: "Selection is illustrative until a server-owned salience contract exists"
  }, "Illustrative selection")), /*#__PURE__*/React.createElement("h1", {
    className: "ik-statement",
    style: size === "md" ? {
      fontSize: "var(--font-size-display-sm)"
    } : undefined
  }, statement), lede && /*#__PURE__*/React.createElement("p", {
    className: "ik-prose",
    style: {
      color: "var(--text-muted)",
      margin: 0
    }
  }, lede), facts.length > 0 && /*#__PURE__*/React.createElement("dl", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: "16px 40px",
      margin: "28px 0 0"
    }
  }, facts.map((f, i) => /*#__PURE__*/React.createElement("div", {
    key: i
  }, /*#__PURE__*/React.createElement("dd", {
    style: {
      margin: 0
    }
  }, f.value), /*#__PURE__*/React.createElement("dt", {
    className: "ik-cap",
    style: {
      marginTop: 6
    }
  }, f.label)))), evidence && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 22
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.EvidenceBadge, {
    evidence: evidence,
    suffix: evidenceSuffix
  })));
}
Object.assign(__ds_scope, { Standout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/report/Standout.jsx", error: String((e && e.message) || e) }); }

// components/share/ShareCard.jsx
try { (() => {
const PLANES = {
  paper: ["var(--plane-paper)", "var(--on-plane-dark)", "var(--pencil)"],
  cobalt: ["var(--plane-cobalt)", "var(--on-plane-light)", "var(--on-plane-light)"],
  tomato: ["var(--plane-tomato)", "var(--on-plane-dark)", "var(--on-plane-dark)"],
  butter: ["var(--plane-butter)", "var(--on-plane-dark)", "var(--on-plane-dark)"],
  moss: ["var(--plane-moss)", "var(--on-plane-light)", "var(--on-plane-light)"]
};
function ShareCard({
  format = "square",
  plane = "paper",
  kicker,
  statement,
  value,
  valueLabel,
  evidence = "COMPUTATIONAL_PROXY",
  evidenceSuffix = "not calibrated",
  visual,
  footer = "Revision 1",
  scale = 1,
  locale = "en"
}) {
  const [bg, fg, acc] = PLANES[plane] ?? PLANES.paper;
  const story = format === "story",
    k = story ? 1.15 : 1;
  const card = /*#__PURE__*/React.createElement("div", {
    className: `ik-share ik-share--${format}`,
    style: {
      background: bg,
      color: fg
    },
    "data-plane": plane
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: `500 ${40 * k}px var(--font-serif)`
    }
  }, "Inktrospect"), /*#__PURE__*/React.createElement("span", {
    style: {
      font: `500 ${22 * k}px var(--font-mono)`,
      letterSpacing: ".1em",
      textTransform: "uppercase"
    }
  }, footer)), kicker && /*#__PURE__*/React.createElement("div", {
    style: {
      font: `500 ${24 * k}px var(--font-mono)`,
      letterSpacing: ".1em",
      textTransform: "uppercase",
      color: acc,
      marginTop: story ? 180 : 64
    }
  }, kicker), /*#__PURE__*/React.createElement("div", {
    style: {
      font: `italic 300 ${story ? 150 : 124}px/1 var(--font-serif)`,
      letterSpacing: "-.03em",
      marginTop: 20,
      textWrap: "balance"
    }
  }, statement), visual && /*#__PURE__*/React.createElement("div", {
    style: {
      margin: story ? "100px 0 0" : "44px 30px 0"
    }
  }, visual), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-end",
      gap: 24,
      borderTop: `2px solid ${fg}`,
      paddingTop: 28,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("div", null, value && /*#__PURE__*/React.createElement("div", {
    style: {
      font: `400 ${story ? 110 : 88}px/1 var(--font-serif)`,
      fontVariantNumeric: "tabular-nums lining-nums"
    }
  }, value), valueLabel && /*#__PURE__*/React.createElement("div", {
    style: {
      font: `500 ${22 * k}px var(--font-mono)`,
      letterSpacing: ".1em",
      textTransform: "uppercase",
      marginTop: 10
    }
  }, valueLabel)), /*#__PURE__*/React.createElement("span", {
    style: {
      font: `500 ${22 * k}px var(--font-mono)`,
      letterSpacing: ".08em",
      textTransform: "uppercase",
      borderBottom: `2px ${evidence === "COMPUTATIONAL_PROXY" ? "dashed" : "solid"} currentColor`,
      paddingBottom: 6
    }
  }, __ds_scope.EVIDENCE_GLYPH[evidence], " ", __ds_scope.t(locale, `evidence.${evidence}`), evidenceSuffix ? " · " + evidenceSuffix : "")));
  if (scale === 1) return card;
  const W = 1080 * scale,
    H = (story ? 1920 : 1080) * scale;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: W,
      height: H,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      transform: `scale(${scale})`,
      transformOrigin: "0 0"
    }
  }, card));
}
Object.assign(__ds_scope, { ShareCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/share/ShareCard.jsx", error: String((e && e.message) || e) }); }

// directions/ink-data.js
try { (() => {
// Synthetic fixture geometry from HMarcusWH/YouAreASpecialLittlePrincess fixtures/reports (evidence-bundle.json, view.free.json).
// Frame: frame_analysis 713x316 px. Components: [x,y,w,h,slantDeg|null,accepted|null].
window.INK = {
  "frame": {
    "w": 713,
    "h": 316
  },
  "lines": [[31, 64, 419, 30], [31, 142, 315, 31], [32, 219, 347, 32]],
  "baselines": [[[31, 73], [71, 85], [119, 86], [151, 86], [191, 82], [223, 84], [263, 74], [311, 84], [343, 73], [375, 86], [407, 84], [447, 82]], [[31, 161], [61, 160], [85, 156], [121, 163], [151, 155], [175, 164], [199, 159], [229, 163], [253, 163], [295, 164], [319, 162], [343, 157]], [[32, 230], [62, 237], [92, 228], [116, 240], [152, 241], [182, 240], [212, 239], [248, 239], [290, 238], [314, 228], [344, 235], [374, 238]]],
  "baselineAngles": [-0.201, -0.748, -0.301],
  "lineGaps": [48, 46],
  "components": [[296, 63, 15, 25, 22.89, 1], [31, 64, 13, 24, 5.07, 1], [44, 64, 19, 24, -1.66, 0], [136, 64, 5, 4, null, null], [159, 64, 18, 24, 6.14, 1], [186, 64, 18, 24, 4.44, 0], [359, 64, 5, 4, null, null], [65, 70, 17, 18, 35.14, 0], [92, 70, 19, 24, 6.04, 0], [113, 71, 18, 17, 58.86, 0], [132, 71, 8, 17, 13.6, 1], [141, 70, 17, 18, 28.17, 0], [206, 71, 14, 17, 30.98, 1], [220, 70, 17, 18, 40.58, 0], [241, 71, 25, 17, 80.03, 0], [266, 70, 19, 18, 56.05, 0], [308, 70, 18, 18, 40.49, 0], [326, 71, 20, 17, 34.28, 0], [350, 71, 13, 23, 19.38, 1], [364, 71, 18, 17, 56.69, 0], [383, 70, 28, 18, 83.16, 0], [412, 70, 19, 24, 34.69, 1], [433, 70, 17, 18, 21.13, 1], [214, 142, 9, 24, 12.65, 1], [287, 142, 20, 24, 35.06, 1], [31, 148, 17, 18, 39.46, 0], [52, 148, 17, 18, 36.71, 0], [69, 148, 17, 18, 33.34, 0], [87, 148, 15, 18, 31.5, 1], [109, 148, 19, 18, 40.61, 0], [139, 148, 17, 18, 38.16, 0], [156, 148, 17, 18, 33.84, 0], [174, 148, 33, 24, 81.12, 0], [223, 148, 19, 18, 40.12, 0], [242, 148, 17, 18, 17.07, 1], [261, 148, 18, 24, 24.12, 1], [307, 148, 18, 18, 40.26, 0], [325, 148, 21, 25, 22.52, 1], [75, 219, 5, 5, null, null], [97, 219, 5, 5, null, null], [274, 219, 15, 25, 23.76, 1], [290, 219, 5, 5, null, null], [80, 220, 13, 24, 5.09, 1], [237, 220, 9, 24, 12.55, 1], [314, 220, 13, 24, 4.87, 1], [32, 226, 25, 18, 79.33, 0], [57, 226, 15, 18, 31.77, 1], [71, 226, 7, 18, 12.41, 1], [93, 226, 8, 18, 12.24, 1], [102, 226, 18, 18, 54.01, 0], [121, 226, 20, 25, 24.11, 1], [151, 226, 16, 18, 20.3, 1], [168, 226, 19, 18, 41.13, 0], [187, 226, 28, 18, 83.84, 0], [215, 226, 20, 24, 34.35, 1], [247, 226, 17, 18, 34.3, 0], [286, 226, 8, 18, 12.89, 1], [293, 226, 20, 18, 27.84, 0], [328, 226, 19, 18, 53.69, 0], [348, 226, 14, 18, 30.8, 1], [362, 226, 17, 18, 33.98, 0]],
  "facts": {
    "IMG_WIDTH_PX": {
      "v": 900,
      "u": "px",
      "a": "READY",
      "e": "MEASURED",
      "n": 1,
      "p": 1,
      "k": "measurement.px",
      "m": "input_dimensions_v1",
      "r": null
    },
    "IMG_HEIGHT_PX": {
      "v": 360,
      "u": "px",
      "a": "READY",
      "e": "MEASURED",
      "n": 1,
      "p": 1,
      "k": "measurement.px",
      "m": "input_dimensions_v1",
      "r": null
    },
    "IMG_MEGAPIXELS": {
      "v": 0.324,
      "u": "MP",
      "a": "READY",
      "e": "MEASURED",
      "n": 1,
      "p": 2,
      "k": "measurement.MP",
      "m": "input_dimensions_v1",
      "r": null
    },
    "IMG_ASPECT_RATIO": {
      "v": 2.5,
      "u": "ratio",
      "a": "READY",
      "e": "MEASURED",
      "n": 1,
      "p": 2,
      "k": "measurement.ratio",
      "m": "input_dimensions_v1",
      "r": null
    },
    "IMG_ROTATION_DEG": {
      "v": 3.0000000000000426,
      "u": "degrees",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 1,
      "p": 1,
      "k": "measurement.degrees",
      "m": "text_skew_ccw_v1",
      "r": null
    },
    "PAGE_LINE_COUNT": {
      "v": 3,
      "u": "count",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 1,
      "p": 0,
      "k": "measurement.count",
      "m": "accepted_segmentation_census_v1",
      "r": null
    },
    "PAGE_WORD_COUNT": {
      "v": 3,
      "u": "count",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 1,
      "p": 0,
      "k": "measurement.count",
      "m": "accepted_segmentation_census_v1",
      "r": null
    },
    "PAGE_COMPONENT_COUNT": {
      "v": 61,
      "u": "count",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 1,
      "p": 0,
      "k": "measurement.count",
      "m": "accepted_segmentation_census_v1",
      "r": null
    },
    "PAGE_INK_AREA_RATIO": {
      "v": 0.044357057894082765,
      "u": "ratio",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 1,
      "p": 2,
      "k": "measurement.ratio",
      "m": "accepted_segmentation_census_v1",
      "r": null
    },
    "PAGE_TEXT_AREA_RATIO": {
      "v": 0.34775951142436135,
      "u": "ratio",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 1,
      "p": 2,
      "k": "measurement.ratio",
      "m": "accepted_segmentation_census_v1",
      "r": null
    },
    "X_HEIGHT_PX": {
      "v": 18,
      "u": "px",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 37,
      "p": 1,
      "k": "measurement.px",
      "m": "component_height_mode_v1",
      "r": null
    },
    "GLYPH_HEIGHT_MEAN": {
      "v": 19.982142857142858,
      "u": "px",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 56,
      "p": 1,
      "k": "measurement.px",
      "m": "component_box_size_v1",
      "r": null
    },
    "GLYPH_HEIGHT_CV": {
      "v": 0.15117040917710878,
      "u": "cv",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 56,
      "p": 2,
      "k": "measurement.cv",
      "m": "component_box_size_v1",
      "r": null
    },
    "GLYPH_WIDTH_MEAN": {
      "v": 17.232142857142858,
      "u": "px",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 56,
      "p": 1,
      "k": "measurement.px",
      "m": "component_box_size_v1",
      "r": null
    },
    "GLYPH_WIDTH_CV": {
      "v": 0.2789528749360222,
      "u": "cv",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 56,
      "p": 2,
      "k": "measurement.cv",
      "m": "component_box_size_v1",
      "r": null
    },
    "GLYPH_ASPECT_RATIO_MEAN": {
      "v": 0.881054302155645,
      "u": "ratio",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 56,
      "p": 2,
      "k": "measurement.ratio",
      "m": "component_box_size_v1",
      "r": null
    },
    "GLYPH_ASPECT_RATIO_CV": {
      "v": 0.31157217121132835,
      "u": "cv",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 56,
      "p": 2,
      "k": "measurement.cv",
      "m": "component_box_size_v1",
      "r": null
    },
    "SLANT_ANGLE_MEAN": {
      "v": 20.075050431612258,
      "u": "degrees",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 26,
      "p": 1,
      "k": "measurement.degrees",
      "m": "oriented_component_axis_v1",
      "r": null
    },
    "SLANT_ANGLE_MEDIAN": {
      "v": 20.71525089687971,
      "u": "degrees",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 26,
      "p": 1,
      "k": "measurement.degrees",
      "m": "oriented_component_axis_v1",
      "r": null
    },
    "SLANT_ANGLE_STD": {
      "v": 9.637173095693731,
      "u": "degrees",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 26,
      "p": 1,
      "k": "measurement.degrees",
      "m": "oriented_component_axis_v1",
      "r": null
    },
    "SLANT_P05": {
      "v": 5.07681240002939,
      "u": "degrees",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 26,
      "p": 1,
      "k": "measurement.degrees",
      "m": "oriented_component_axis_v1",
      "r": null
    },
    "SLANT_P95": {
      "v": 34.60893307811425,
      "u": "degrees",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 26,
      "p": 1,
      "k": "measurement.degrees",
      "m": "oriented_component_axis_v1",
      "r": null
    },
    "SLANT_LEFT_FRACTION": {
      "v": 0,
      "u": "ratio",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 26,
      "p": 2,
      "k": "measurement.ratio",
      "m": "oriented_component_axis_v1",
      "r": null
    },
    "SLANT_VERTICAL_FRACTION": {
      "v": 0.038461538461538464,
      "u": "ratio",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 26,
      "p": 2,
      "k": "measurement.ratio",
      "m": "oriented_component_axis_v1",
      "r": null
    },
    "SLANT_RIGHT_FRACTION": {
      "v": 0.9615384615384616,
      "u": "ratio",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 26,
      "p": 2,
      "k": "measurement.ratio",
      "m": "oriented_component_axis_v1",
      "r": null
    },
    "SLANT_EXTREME_FRACTION": {
      "v": 0.2692307692307692,
      "u": "ratio",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 26,
      "p": 2,
      "k": "measurement.ratio",
      "m": "oriented_component_axis_v1",
      "r": null
    },
    "SLANT_CONSISTENCY": {
      "v": 0.8393804484051045,
      "u": "score_0_1",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 26,
      "p": 2,
      "k": "measurement.score_0_1",
      "m": "oriented_component_axis_v1",
      "r": null
    },
    "BASELINE_ANGLE_MEAN": {
      "v": -0.41668234220405803,
      "u": "degrees",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 1,
      "k": "measurement.degrees",
      "m": "bottom_quantile_angle_v1",
      "r": null
    },
    "BASELINE_ANGLE_MEDIAN": {
      "v": -0.30099849734013334,
      "u": "degrees",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 1,
      "k": "measurement.degrees",
      "m": "bottom_quantile_angle_v1",
      "r": null
    },
    "BASELINE_ANGLE_STD": {
      "v": 0.23757000882255241,
      "u": "degrees",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 1,
      "k": "measurement.degrees",
      "m": "bottom_quantile_angle_v1",
      "r": null
    },
    "BASELINE_ABS_SLOPE": {
      "v": 0.41668234220405803,
      "u": "degrees",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 1,
      "k": "measurement.degrees",
      "m": "bottom_quantile_angle_v1",
      "r": null
    },
    "BASELINE_WAVINESS": {
      "v": 0.28562284486811274,
      "u": "normalized",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 3,
      "k": "measurement.normalized",
      "m": "baseline_residual_xheight_v1",
      "r": null
    },
    "BASELINE_CURVATURE": {
      "v": 0.16540083580869946,
      "u": "normalized",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 3,
      "k": "measurement.normalized",
      "m": "baseline_quadratic_sag_xheight_v1",
      "r": null
    },
    "BASELINE_STABILITY": {
      "v": 0.7778330977796106,
      "u": "score_0_1",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 2,
      "k": "measurement.score_0_1",
      "m": "baseline_inverse_waviness_index_v1",
      "r": null
    },
    "LINE_SPACING_PX": {
      "v": 47,
      "u": "px",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 2,
      "p": 1,
      "k": "measurement.px",
      "m": "accepted_box_gap_px_v1",
      "r": null
    },
    "LINE_SPACING_REL": {
      "v": 2.611111111111111,
      "u": "xheight_ratio",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 2,
      "p": 2,
      "k": "measurement.xheight_ratio",
      "m": "accepted_box_gap_rel_v1",
      "r": null
    },
    "LINE_SPACING_CV": {
      "v": 0.02127659574468085,
      "u": "cv",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 2,
      "p": 2,
      "k": "measurement.cv",
      "m": "accepted_box_gap_cv_v1",
      "r": null
    },
    "WORD_SPACING_PX": {
      "v": null,
      "u": "px",
      "a": "MISSING",
      "e": "COMPUTATIONAL_PROXY",
      "n": 0,
      "p": 1,
      "k": "measurement.px",
      "m": "accepted_box_gap_px_v1",
      "r": "no_valid_gaps_or_xheight_unavailable"
    },
    "WORD_SPACING_REL": {
      "v": null,
      "u": "xheight_ratio",
      "a": "MISSING",
      "e": "COMPUTATIONAL_PROXY",
      "n": 0,
      "p": 2,
      "k": "measurement.xheight_ratio",
      "m": "accepted_box_gap_rel_v1",
      "r": "no_valid_gaps_or_xheight_unavailable"
    },
    "WORD_SPACING_CV": {
      "v": null,
      "u": "cv",
      "a": "MISSING",
      "e": "COMPUTATIONAL_PROXY",
      "n": 0,
      "p": 2,
      "k": "measurement.cv",
      "m": "accepted_box_gap_cv_v1",
      "r": "cv_requires_two_observations_and_positive_mean"
    },
    "MARGIN_TOP_REL": {
      "v": 3.5555555555555554,
      "u": "xheight_ratio",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 2,
      "k": "measurement.xheight_ratio",
      "m": "text_bounds_xheight_v1",
      "r": null
    },
    "MARGIN_BOTTOM_REL": {
      "v": 3.611111111111111,
      "u": "xheight_ratio",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 2,
      "k": "measurement.xheight_ratio",
      "m": "text_bounds_xheight_v1",
      "r": null
    },
    "MARGIN_LEFT_REL": {
      "v": 1.7222222222222223,
      "u": "xheight_ratio",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 2,
      "k": "measurement.xheight_ratio",
      "m": "text_bounds_xheight_v1",
      "r": null
    },
    "MARGIN_RIGHT_REL": {
      "v": 14.61111111111111,
      "u": "xheight_ratio",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 2,
      "k": "measurement.xheight_ratio",
      "m": "text_bounds_xheight_v1",
      "r": null
    },
    "MARGIN_LEFT_VARIABILITY": {
      "v": 0.015044825131628671,
      "u": "cv",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 2,
      "k": "measurement.cv",
      "m": "line_edge_population_cv_v1",
      "r": null
    },
    "MARGIN_RIGHT_VARIABILITY": {
      "v": 0.13503817722930328,
      "u": "cv",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 2,
      "k": "measurement.cv",
      "m": "line_edge_population_cv_v1",
      "r": null
    },
    "MARGIN_SYMMETRY": {
      "v": 0.2108843537414966,
      "u": "score_0_1",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 2,
      "k": "measurement.score_0_1",
      "m": "margin_balance_index_v1",
      "r": null
    },
    "TEXT_BLOCK_HORIZONTAL_CENTER": {
      "v": 0.3373071528751753,
      "u": "normalized_x",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 3,
      "k": "measurement.normalized_x",
      "m": "text_bounds_canvas_ratio_v1",
      "r": null
    },
    "TEXT_BLOCK_VERTICAL_CENTER": {
      "v": 0.49841772151898733,
      "u": "normalized_y",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 3,
      "k": "measurement.normalized_y",
      "m": "text_bounds_canvas_ratio_v1",
      "r": null
    },
    "PAGE_HORIZONTAL_DENSITY": {
      "v": 0.5876577840112202,
      "u": "ratio",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 2,
      "k": "measurement.ratio",
      "m": "text_bounds_canvas_ratio_v1",
      "r": null
    },
    "PAGE_VERTICAL_DENSITY": {
      "v": 0.5917721518987342,
      "u": "ratio",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 2,
      "k": "measurement.ratio",
      "m": "text_bounds_canvas_ratio_v1",
      "r": null
    },
    "LINE_LENGTH_MEAN_REL": {
      "v": 0.5053763440860215,
      "u": "ratio",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 2,
      "k": "measurement.ratio",
      "m": "line_width_page_ratio_v1",
      "r": null
    },
    "LINE_LENGTH_VARIABILITY": {
      "v": 0.12069940003922362,
      "u": "cv",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 2,
      "k": "measurement.cv",
      "m": "line_edge_population_cv_v1",
      "r": null
    },
    "LINE_START_DRIFT": {
      "v": 0.0028349018892692987,
      "u": "normalized_slope",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 3,
      "k": "measurement.normalized_slope",
      "m": "normalized_edge_vs_vertical_position_v1",
      "r": null
    },
    "LINE_END_DRIFT": {
      "v": -0.20254068851278242,
      "u": "normalized_slope",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 3,
      "p": 3,
      "k": "measurement.normalized_slope",
      "m": "normalized_edge_vs_vertical_position_v1",
      "r": null
    },
    "INK_DARKNESS_MEAN": {
      "v": 0.7882968997084526,
      "u": "normalized",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 9994,
      "p": 3,
      "k": "measurement.normalized",
      "m": "grayscale_darkness_v1",
      "r": null
    },
    "INK_DARKNESS_STD": {
      "v": 0.15468451239905937,
      "u": "normalized",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 9994,
      "p": 3,
      "k": "measurement.normalized",
      "m": "grayscale_darkness_v1",
      "r": null
    },
    "INK_DARKNESS_CV": {
      "v": 0.1962262092572844,
      "u": "cv",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 9994,
      "p": 2,
      "k": "measurement.cv",
      "m": "grayscale_darkness_v1",
      "r": null
    },
    "STROKE_WIDTH_MEAN": {
      "v": 4.3125289637480755,
      "u": "px",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 2300,
      "p": 1,
      "k": "measurement.px",
      "m": "medial_axis_diameter_v1",
      "r": null
    },
    "STROKE_WIDTH_MEDIAN": {
      "v": 4.47213595499958,
      "u": "px",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 2300,
      "p": 1,
      "k": "measurement.px",
      "m": "medial_axis_diameter_v1",
      "r": null
    },
    "STROKE_WIDTH_STD": {
      "v": 0.9931977461316084,
      "u": "px",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 2300,
      "p": 1,
      "k": "measurement.px",
      "m": "medial_axis_diameter_v1",
      "r": null
    },
    "STROKE_WIDTH_CV": {
      "v": 0.23030517695779304,
      "u": "cv",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 2300,
      "p": 2,
      "k": "measurement.cv",
      "m": "medial_axis_diameter_v1",
      "r": null
    },
    "STROKE_UNIFORMITY": {
      "v": 0.8128064635741235,
      "u": "score_0_1",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 2300,
      "p": 2,
      "k": "measurement.score_0_1",
      "m": "medial_axis_diameter_v1",
      "r": null
    },
    "INK_SATURATION_FRACTION": {
      "v": 0.0015009005403241946,
      "u": "ratio",
      "a": "UNCALIBRATED",
      "e": "COMPUTATIONAL_PROXY",
      "n": 9994,
      "p": 2,
      "k": "measurement.ratio",
      "m": "grayscale_darkness_v1",
      "r": null
    }
  },
  "sections": [{
    "id": "section.sample",
    "t": "SAMPLE_SUITABILITY",
    "a": "READY"
  }, {
    "id": "section.size",
    "t": "METRIC_GRID",
    "a": "UNCALIBRATED"
  }, {
    "id": "section.slant",
    "t": "DISTRIBUTION",
    "a": "UNCALIBRATED"
  }, {
    "id": "section.baseline",
    "t": "BASELINE_TRACE",
    "a": "UNCALIBRATED"
  }, {
    "id": "section.spacing",
    "t": "SPACING",
    "a": "UNCALIBRATED"
  }, {
    "id": "section.layout",
    "t": "PAGE_LAYOUT",
    "a": "UNCALIBRATED"
  }, {
    "id": "section.ink",
    "t": "METRIC_GRID",
    "a": "UNCALIBRATED"
  }, {
    "id": "section.reference",
    "t": "REFERENCE",
    "a": "INELIGIBLE"
  }, {
    "id": "section.premium",
    "t": "PREMIUM",
    "a": "LOCKED"
  }],
  "notices": ["notice.measured", "notice.proxy_uncalibrated", "notice.reference_unavailable", "notice.traditional_not_included", "notice.private_report"],
  "actions": [{
    "k": "COMPARE",
    "on": true,
    "r": null
  }, {
    "k": "EXPORT",
    "on": true,
    "r": null
  }, {
    "k": "SHARE",
    "on": true,
    "r": null
  }, {
    "k": "SAVE",
    "on": true,
    "r": null
  }, {
    "k": "DELETE",
    "on": true,
    "r": null
  }, {
    "k": "PURCHASE",
    "on": false,
    "r": "premium_not_yet_available"
  }],
  "revision": 1,
  "reportId": "report_fixture_1"
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "directions/ink-data.js", error: String((e && e.message) || e) }); }

// directions/specimen.js
try { (() => {
// Shared renderers for the three direction explorations. All geometry comes from window.INK (synthetic fixture).
// Glyph text is an ILLUSTRATIVE stand-in: the fixture's source image is not in the repo.
(function () {
  const NS = 'http://www.w3.org/2000/svg';
  const D = () => window.INK;
  const TEXT = ['Handwriting is a quiet', 'record of how I', 'think on paper'];
  function el(tag, attrs, parent) {
    const n = document.createElementNS(NS, tag);
    for (const k in attrs) n.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(n);
    return n;
  }
  function avgY(pts) {
    return pts.reduce((s, p) => s + p[1], 0) / pts.length;
  }
  function fmt(v, p, loc) {
    return new Intl.NumberFormat(loc === 'sv' ? 'sv-SE' : 'en-GB', {
      minimumFractionDigits: p,
      maximumFractionDigits: p
    }).format(v);
  }
  function render(host, o) {
    o = Object.assign({
      ink: '#1b1a17',
      paper: null,
      font: 'Cedarville Cursive',
      fontSize: 38,
      labelFont: 'monospace',
      labelSize: 11,
      stroke: 1.25,
      colors: {},
      layers: {
        baseline: true,
        slant: false,
        spacing: true,
        margins: false,
        lines: false,
        xheight: false,
        components: false
      },
      labels: true,
      pad: 0
    }, o || {});
    const c = Object.assign({
      baseline: '#b23a1e',
      slant: '#b23a1e',
      spacing: '#b23a1e',
      margins: '#8a8475',
      lines: '#8a8475',
      xheight: '#b23a1e',
      components: '#8a8475',
      label: '#b23a1e',
      rejected: '#b9b2a4'
    }, o.colors);
    const d = D(),
      W = d.frame.w,
      H = d.frame.h;
    const svg = el('svg', {
      viewBox: `${-o.pad} ${-o.pad} ${W + 2 * o.pad} ${H + 2 * o.pad}`,
      width: '100%',
      role: 'img',
      'aria-label': 'Annotated handwriting sample (synthetic). Three lines; baseline, slant and spacing overlays.'
    });
    svg.style.display = 'block';
    if (o.paper) el('rect', {
      x: -o.pad,
      y: -o.pad,
      width: W + 2 * o.pad,
      height: H + 2 * o.pad,
      fill: o.paper
    }, svg);
    const L = name => {
      const g = el('g', {
        'data-layer': name
      }, svg);
      if (!o.layers[name]) g.style.display = 'none';
      return g;
    };
    const lab = (g, x, y, t, anchor, col) => {
      if (!o.labels) return;
      const tx = el('text', {
        x,
        y,
        'font-family': o.labelFont,
        'font-size': o.labelSize,
        fill: col || c.label,
        'text-anchor': anchor || 'start',
        'letter-spacing': '0.04em'
      }, g);
      tx.textContent = t;
    };
    // margins (under text)
    const gm = L('margins');
    const right = Math.max(...d.lines.map(l => l[0] + l[2])),
      bottom = Math.max(...d.lines.map(l => l[1] + l[3]));
    [[0, 0, 31, H], [right, 0, W - right, H]].forEach(r => el('rect', {
      x: r[0],
      y: r[1],
      width: r[2],
      height: r[3],
      fill: c.margins,
      opacity: 0.1
    }, gm));
    [[31], [right]].forEach(x => el('line', {
      x1: x,
      y1: 0,
      x2: x,
      y2: H,
      stroke: c.margins,
      'stroke-width': 1,
      'stroke-dasharray': '3 3',
      'vector-effect': 'non-scaling-stroke'
    }, gm));
    lab(gm, right + 10, 24, 'RIGHT 14.61 × x-height', 'start', c.margins);
    lab(gm, 36, H - 10, 'LEFT 1.72', 'start', c.margins);
    // handwriting
    const gt = el('g', {
      'data-layer': 'ink'
    }, svg);
    d.lines.forEach((l, i) => {
      const t = el('text', {
        x: l[0],
        y: avgY(d.baselines[i]) + 1,
        'font-family': o.font,
        'font-size': o.fontSize,
        fill: o.ink,
        textLength: l[2],
        lengthAdjust: 'spacingAndGlyphs'
      }, gt);
      t.textContent = TEXT[i];
    });
    // lines
    const gl = L('lines');
    d.lines.forEach((l, i) => {
      el('rect', {
        x: l[0],
        y: l[1],
        width: l[2],
        height: l[3],
        fill: 'none',
        stroke: c.lines,
        'stroke-width': 1,
        'stroke-dasharray': '2 3',
        'vector-effect': 'non-scaling-stroke'
      }, gl);
      lab(gl, l[0] + l[2] + 6, l[1] + 10, 'line_' + i, 'start', c.lines);
    });
    // components
    const gc = L('components');
    d.components.forEach(k => el('rect', {
      x: k[0],
      y: k[1],
      width: k[2],
      height: k[3],
      fill: 'none',
      stroke: c.components,
      'stroke-width': 0.75,
      'vector-effect': 'non-scaling-stroke'
    }, gc));
    // x-height band on line 0
    const gx = L('xheight');
    const b0 = avgY(d.baselines[0]);
    el('rect', {
      x: d.lines[0][0],
      y: b0 - 18,
      width: d.lines[0][2],
      height: 18,
      fill: c.xheight,
      opacity: 0.1
    }, gx);
    [b0 - 18, b0].forEach(y => el('line', {
      x1: d.lines[0][0] - 8,
      y1: y,
      x2: d.lines[0][0] + d.lines[0][2],
      y2: y,
      stroke: c.xheight,
      'stroke-width': 1,
      'vector-effect': 'non-scaling-stroke'
    }, gx));
    lab(gx, d.lines[0][0] + d.lines[0][2] + 6, b0 - 5, 'x-height 18 px', 'start', c.xheight);
    // baseline
    const gb = L('baseline');
    d.baselines.forEach((pts, i) => {
      el('polyline', {
        points: pts.map(p => p.join(',')).join(' '),
        fill: 'none',
        stroke: c.baseline,
        'stroke-width': o.stroke,
        'vector-effect': 'non-scaling-stroke',
        'stroke-linejoin': 'round'
      }, gb);
      pts.forEach(p => el('circle', {
        cx: p[0],
        cy: p[1],
        r: 2,
        fill: c.baseline
      }, gb));
      const last = pts[pts.length - 1];
      lab(gb, last[0] + 8, last[1] + 4, fmt(d.baselineAngles[i], 2) + '°');
    });
    // slant ticks
    const gs = L('slant');
    d.components.forEach(k => {
      if (k[4] === null) return;
      const cx = k[0] + k[2] / 2,
        cy = k[1] + k[3] / 2,
        len = Math.max(k[3], 16) * 1.1,
        a = k[4] * Math.PI / 180;
      const dx = Math.sin(a) * len / 2,
        dy = Math.cos(a) * len / 2;
      el('line', {
        x1: cx - dx,
        y1: cy + dy,
        x2: cx + dx,
        y2: cy - dy,
        stroke: k[5] ? c.slant : c.rejected,
        'stroke-width': k[5] ? 1.5 : 1,
        'stroke-dasharray': k[5] ? '' : '2 2',
        'vector-effect': 'non-scaling-stroke',
        'stroke-linecap': 'round'
      }, gs);
    });
    // spacing brackets
    const gp = L('spacing'),
      bx = Math.min(...d.lines.map(l => l[0])) - 14;
    for (let i = 0; i < 2; i++) {
      const y1 = d.lines[i][1] + d.lines[i][3],
        y2 = d.lines[i + 1][1];
      el('path', {
        d: `M${bx + 5},${y1} H${bx} V${y2} H${bx + 5}`,
        fill: 'none',
        stroke: c.spacing,
        'stroke-width': 1.25,
        'vector-effect': 'non-scaling-stroke'
      }, gp);
      lab(gp, bx - 6, (y1 + y2) / 2 + 4, d.lineGaps[i] + ' px', 'end', c.spacing);
    }
    host.innerHTML = '';
    host.appendChild(svg);
    return svg;
  }
  function setLayer(svg, name, on) {
    const g = svg.querySelector(`[data-layer="${name}"]`);
    if (g) g.style.display = on ? '' : 'none';
  }

  // Derived visual: every slant observation drawn as a ray on a fixed -90..90° scale. No handwriting exposed.
  function fan(host, o) {
    o = Object.assign({
      color: '#1b1a17',
      rejected: '#b9b2a4',
      showRejected: true,
      axis: '#8a8475',
      r: 100,
      stroke: 1.5,
      labels: true,
      labelFont: 'monospace',
      labelSize: 9,
      mean: null,
      meanColor: null
    }, o || {});
    const R = o.r,
      svg = el('svg', {
        viewBox: `${-R - 12} ${-R - 16} ${2 * R + 24} ${R + 30}`,
        width: '100%',
        role: 'img',
        'aria-label': 'Slant observations on a fixed scale from 90° left to 90° right.'
      });
    svg.style.display = 'block';
    el('path', {
      d: `M${-R},0 A${R},${R} 0 0 1 ${R},0`,
      fill: 'none',
      stroke: o.axis,
      'stroke-width': 1,
      'vector-effect': 'non-scaling-stroke'
    }, svg);
    el('line', {
      x1: -R,
      y1: 0,
      x2: R,
      y2: 0,
      stroke: o.axis,
      'stroke-width': 1,
      'vector-effect': 'non-scaling-stroke'
    }, svg);
    [-60, -30, 0, 30, 60].forEach(a => {
      const t = a * Math.PI / 180;
      el('line', {
        x1: Math.sin(t) * R,
        y1: -Math.cos(t) * R,
        x2: Math.sin(t) * (R + 5),
        y2: -Math.cos(t) * (R + 5),
        stroke: o.axis,
        'stroke-width': 1,
        'vector-effect': 'non-scaling-stroke'
      }, svg);
      if (o.labels) {
        const tx = el('text', {
          x: Math.sin(t) * (R + 12),
          y: -Math.cos(t) * (R + 12) + 3,
          'font-family': o.labelFont,
          'font-size': o.labelSize,
          fill: o.axis,
          'text-anchor': 'middle'
        }, svg);
        tx.textContent = (a > 0 ? '+' : '') + a + '°';
      }
    });
    D().components.forEach(k => {
      if (k[4] === null || !k[5] && !o.showRejected) return;
      const t = k[4] * Math.PI / 180,
        rr = R * 0.92;
      el('line', {
        x1: 0,
        y1: 0,
        x2: Math.sin(t) * rr,
        y2: -Math.cos(t) * rr,
        stroke: k[5] ? o.color : o.rejected,
        'stroke-width': k[5] ? o.stroke : 1,
        'stroke-dasharray': k[5] ? '' : '2 3',
        'vector-effect': 'non-scaling-stroke',
        opacity: k[5] ? 0.85 : 0.7
      }, svg);
    });
    if (o.mean !== null) {
      const t = o.mean * Math.PI / 180;
      el('line', {
        x1: 0,
        y1: 0,
        x2: Math.sin(t) * (R + 4),
        y2: -Math.cos(t) * (R + 4),
        stroke: o.meanColor || o.color,
        'stroke-width': 3,
        'vector-effect': 'non-scaling-stroke',
        'stroke-linecap': 'round'
      }, svg);
    }
    el('circle', {
      cx: 0,
      cy: 0,
      r: 3,
      fill: o.meanColor || o.color
    }, svg);
    host.innerHTML = '';
    host.appendChild(svg);
    return svg;
  }

  // Derived visual: the three baseline traces, vertically exaggerated, no glyphs.
  function traces(host, o) {
    o = Object.assign({
      color: '#1b1a17',
      guide: '#8a8475',
      exaggerate: 3,
      gap: 40,
      stroke: 2,
      dots: true
    }, o || {});
    const d = D(),
      w = 460,
      h = o.gap * 3;
    const svg = el('svg', {
      viewBox: `0 0 ${w} ${h}`,
      width: '100%',
      role: 'img',
      'aria-label': 'Three baseline traces from stored baseline points, vertical deviation exaggerated.'
    });
    svg.style.display = 'block';
    d.baselines.forEach((pts, i) => {
      const my = avgY(pts),
        cy = o.gap * (i + 0.5),
        x0 = pts[0][0];
      el('line', {
        x1: 0,
        y1: cy,
        x2: w,
        y2: cy,
        stroke: o.guide,
        'stroke-width': 1,
        'stroke-dasharray': '2 4',
        'vector-effect': 'non-scaling-stroke'
      }, svg);
      const P = pts.map(p => [(p[0] - x0) * (w - 20) / 440 + 10, cy + (p[1] - my) * o.exaggerate / 3]);
      el('polyline', {
        points: P.map(p => p.join(',')).join(' '),
        fill: 'none',
        stroke: o.color,
        'stroke-width': o.stroke,
        'stroke-linejoin': 'round',
        'vector-effect': 'non-scaling-stroke'
      }, svg);
      if (o.dots) P.forEach(p => el('circle', {
        cx: p[0],
        cy: p[1],
        r: 2.2,
        fill: o.color
      }, svg));
    });
    host.innerHTML = '';
    host.appendChild(svg);
    return svg;
  }
  window.Specimen = {
    render,
    setLayer,
    fan,
    traces,
    fmt
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "directions/specimen.js", error: String((e && e.message) || e) }); }

// ui_kits/app/capture-screen.jsx
try { (() => {
(() => {
  const {
    UploadField,
    ConsentChoice,
    Button
  } = window.IK;
  function CaptureScreen({
    go
  }) {
    const [file, setFile] = React.useState(null),
      [svc, setSvc] = React.useState(false),
      [keep, setKeep] = React.useState(false),
      [ai, setAi] = React.useState(false);
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,420px),1fr))",
        gap: "40px 64px",
        paddingTop: 56
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "ik-cap ik-cap--accent"
    }, "New sample"), /*#__PURE__*/React.createElement("h1", {
      className: "ik-statement",
      style: {
        fontSize: "var(--font-size-display-md)"
      }
    }, "One page of your handwriting, measured."), /*#__PURE__*/React.createElement("p", {
      className: "ik-prose",
      style: {
        color: "var(--text-muted)"
      }
    }, "Write a few lines on plain paper and take a straight-on photo in even light. The free report measures size, slant, baseline, spacing, layout and ink. No AI is used."), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 28
      }
    }, /*#__PURE__*/React.createElement(UploadField, {
      fileName: file ? file.name || file : null,
      onPick: setFile
    })), /*#__PURE__*/React.createElement("button", {
      className: "ik-btn ik-btn--ghost",
      style: {
        padding: 0,
        marginTop: 8
      },
      onClick: () => setFile("synthetic-sample.png")
    }, "Use the synthetic sample")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "ik-cap"
    }, "Your choices"), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 14
      }
    }, /*#__PURE__*/React.createElement(ConsentChoice, {
      id: "svc",
      required: true,
      checked: svc,
      onChange: setSvc,
      title: "Analyse this page",
      description: "We process this photo of your own handwriting to measure it and build your report. You can withdraw this permission later, which deletes the report."
    }), /*#__PURE__*/React.createElement(ConsentChoice, {
      id: "keep",
      checked: keep,
      onChange: setKeep,
      title: "Keep the image with the report",
      description: "Lets the report keep showing your writing alongside its measurements. Without it, the report keeps the measurements only."
    }), /*#__PURE__*/React.createElement(ConsentChoice, {
      id: "ai",
      checked: ai,
      onChange: setAi,
      title: "Allow AI-assisted processing (Premium)",
      description: "Only used if you later choose Premium. Sends the image and evidence to a third-party AI provider.",
      note: "None of these optional choices are needed for the free report."
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 24
      }
    }, /*#__PURE__*/React.createElement(Button, {
      block: true,
      disabled: !file || !svc,
      onClick: () => go("processing"),
      reason: !file ? "Choose a photo first." : !svc ? "The report needs permission to analyse this page." : undefined
    }, "Analyse my handwriting"))));
  }
  window.CaptureScreen = CaptureScreen;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/capture-screen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/history-screen.jsx
try { (() => {
(() => {
  const {
    Button,
    EvidenceBadge,
    SlantFan,
    SampleEvidence: E
  } = window.IK;
  const OBS = E.components.filter(k => k[4] !== null).map(k => ({
    value: k[4],
    accepted: !!k[5]
  }));
  function HistoryScreen({
    go
  }) {
    const rows = [{
      id: "report_fixture_1",
      date: "27 Sep 2026",
      rev: 2,
      title: "Leans right",
      note: "Revision 2 · Premium overlay attached",
      fan: true
    }, {
      id: "report_fixture_1",
      date: "27 Sep 2026",
      rev: 1,
      title: "Leans right",
      note: "Revision 1 · Free",
      fan: true
    }, {
      id: "deleted",
      date: "—",
      rev: null,
      title: "Sample deleted",
      note: "The capture was deleted. Its report is no longer available.",
      fan: false
    }];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        paddingTop: 48
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "flex-end",
        gap: 20,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "ik-cap ik-cap--accent"
    }, "Your reports"), /*#__PURE__*/React.createElement("h1", {
      className: "ik-section__title"
    }, "History")), /*#__PURE__*/React.createElement(Button, {
      onClick: () => go("capture")
    }, "New sample")), /*#__PURE__*/React.createElement("ol", {
      style: {
        listStyle: "none",
        padding: 0,
        margin: "32px 0 0"
      }
    }, rows.map((r, i) => /*#__PURE__*/React.createElement("li", {
      key: i,
      style: {
        display: "grid",
        gridTemplateColumns: "120px 1fr auto",
        gap: 24,
        alignItems: "center",
        padding: "20px 0",
        borderTop: "1px solid var(--border-hairline)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "ik-plate",
      style: {
        padding: 8,
        opacity: r.fan ? 1 : .5
      }
    }, r.fan ? /*#__PURE__*/React.createElement(SlantFan, {
      observations: OBS,
      showRejected: false,
      labels: false
    }) : /*#__PURE__*/React.createElement("div", {
      className: "ik-hatch",
      style: {
        height: 52
      }
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: "italic 300 28px/1.1 var(--font-serif)"
      }
    }, r.title), /*#__PURE__*/React.createElement("div", {
      className: "ik-cap",
      style: {
        marginTop: 6,
        textTransform: "none",
        letterSpacing: 0,
        fontSize: 12
      }
    }, r.date, " \xB7 ", r.note), r.rev === 2 && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 8
      }
    }, /*#__PURE__*/React.createElement(EvidenceBadge, {
      evidence: "AI_SYNTHESIS",
      suffix: "saved with this revision"
    }))), r.fan ? /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      onClick: () => go("report")
    }, "Open") : /*#__PURE__*/React.createElement("span", {
      className: "ik-unavailable"
    }, "No longer available")))));
  }
  function CompareScreen({
    go
  }) {
    const {
      HandwritingCanvas,
      RangeBar,
      SampleEvidence
    } = window.IK;
    return /*#__PURE__*/React.createElement("div", {
      style: {
        paddingTop: 48
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 12,
        alignItems: "center",
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "ik-cap ik-cap--accent"
    }, "Compare"), /*#__PURE__*/React.createElement("span", {
      className: "ik-illustrative"
    }, "Planned \xB7 T18 / T22 \xB7 structure only")), /*#__PURE__*/React.createElement("h1", {
      className: "ik-section__title"
    }, "Me vs me"), /*#__PURE__*/React.createElement("p", {
      className: "ik-prose",
      style: {
        color: "var(--text-muted)"
      }
    }, "Comparison is not available yet. This layout shows where two samples would sit side by side, with shared measurement families on the same fixed scales. No differences are shown until a comparison contract exists."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,380px),1fr))",
        gap: 24,
        marginTop: 28
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "ik-cap",
      style: {
        marginBottom: 8
      }
    }, "A \xB7 27 Sep 2026 \xB7 rev 1"), /*#__PURE__*/React.createElement(HandwritingCanvas, {
      evidence: SampleEvidence,
      layers: ["slant"],
      labels: false,
      loupe: false,
      fontSize: 38
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "ik-cap",
      style: {
        marginBottom: 8
      }
    }, "B \xB7 choose a report"), /*#__PURE__*/React.createElement("div", {
      className: "ik-plate",
      style: {
        minHeight: 220,
        display: "grid",
        placeItems: "center",
        borderStyle: "dashed"
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "ik-btn ik-btn--secondary",
      onClick: () => go("history")
    }, "Choose a second report")))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 22,
        marginTop: 36,
        maxWidth: 640
      }
    }, /*#__PURE__*/React.createElement(RangeBar, {
      label: "Mean slant \xB7 A",
      domain: [-90, 90],
      ticks: [-90, 0, 90],
      value: 20.1,
      band: [5.1, 34.6],
      unit: "\xB0"
    }), /*#__PURE__*/React.createElement(RangeBar, {
      label: "Mean slant \xB7 B",
      domain: [-90, 90],
      ticks: [-90, 0, 90],
      value: null,
      missingLabel: "No second report selected"
    })));
  }
  window.HistoryScreen = HistoryScreen;
  window.CompareScreen = CompareScreen;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/history-screen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/processing-screen.jsx
try { (() => {
(() => {
  const {
    JobStatus,
    Button,
    Standout,
    SlantFan,
    FactValue,
    SampleEvidence: E,
    SampleFacts: F
  } = window.IK;
  const OBS = E.components.filter(k => k[4] !== null).map(k => ({
    value: k[4],
    accepted: !!k[5]
  }));
  function ProcessingScreen({
    go
  }) {
    const [step, setStep] = React.useState(0);
    React.useEffect(() => {
      if (step >= 3) return;
      const id = setTimeout(() => setStep(s => s + 1), 900);
      return () => clearTimeout(id);
    }, [step]);
    const steps = ["Photo checked", "Finding lines and letters", "Measuring geometry", "Building your report"].map((label, i) => ({
      label,
      state: i < step ? "done" : i === step ? "active" : "todo"
    }));
    if (step < 3) return /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 560,
        margin: "0 auto",
        paddingTop: 96
      }
    }, /*#__PURE__*/React.createElement(JobStatus, {
      status: "RUNNING",
      steps: steps,
      detail: "You can leave this page; the analysis continues and your report is saved."
    }));
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,420px),1fr))",
        gap: 56,
        paddingTop: 56,
        alignItems: "center"
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "ik-cap",
      style: {
        marginBottom: 20
      }
    }, "Report ready \xB7 Revision 1"), /*#__PURE__*/React.createElement(Standout, {
      statement: "Almost every letter we could read leans to the right.",
      facts: [{
        label: "Mean slant",
        value: /*#__PURE__*/React.createElement(FactValue, {
          fact: F.SLANT_ANGLE_MEAN,
          showCalibration: false,
          size: "lg"
        })
      }],
      evidence: "COMPUTATIONAL_PROXY",
      evidenceSuffix: "not calibrated"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 12,
        marginTop: 32,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement(Button, {
      onClick: () => go("report")
    }, "See where it was measured"), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      onClick: () => go("report")
    }, "Open full report"))), /*#__PURE__*/React.createElement("figure", {
      style: {
        margin: 0
      },
      className: "ik-plate"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 28
      }
    }, /*#__PURE__*/React.createElement(SlantFan, {
      observations: OBS,
      mean: 20.08
    }))));
  }
  window.ProcessingScreen = ProcessingScreen;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/processing-screen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/report-screen.jsx
try { (() => {
(() => {
  const {
    Standout,
    SlantFan,
    RangeBar,
    FactValue,
    EvidenceBadge,
    ReportSection,
    HandwritingCanvas,
    LayerToggles,
    MarginNote,
    NoticeBar,
    ActionBar,
    BaselineTrace,
    PageMap,
    QualityHint,
    SampleEvidence: E,
    SampleFacts: F
  } = window.IK;
  const OBS = E.components.filter(k => k[4] !== null).map(k => ({
    value: k[4],
    accepted: !!k[5]
  }));
  const FAMILIES = [["Sample suitability", "◆ Measured", "MEASURED"], ["Size", "Not calibrated"], ["Slant", "Not calibrated"], ["Baseline", "Not calibrated"], ["Spacing", "1 of 2 not measured"], ["Page layout", "Not calibrated"], ["Ink", "Not calibrated"], ["Reference comparison", "Not applicable to this sample", "i"], ["Interpretation", "⌂ Available with Premium"]];
  const ACTIONS = [{
    kind: "COMPARE",
    enabled: true
  }, {
    kind: "EXPORT",
    enabled: true
  }, {
    kind: "SHARE",
    enabled: true
  }, {
    kind: "SAVE",
    enabled: true
  }, {
    kind: "DELETE",
    enabled: true
  }, {
    kind: "PURCHASE",
    enabled: false,
    reason: "premium_not_yet_available"
  }];
  function ReportScreen({
    go,
    locale
  }) {
    const [layers, setLayers] = React.useState(["baseline", "spacing"]);
    const one = k => setLayers([k]);
    return /*#__PURE__*/React.createElement("article", {
      lang: locale
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        flexWrap: "wrap",
        gap: 8,
        padding: "40px 0 16px"
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "ik-cap"
    }, "Free report \xB7 Revision 1 \xB7 27 Sep 2026"), /*#__PURE__*/React.createElement("span", {
      className: "ik-cap"
    }, "\u2302 Private to your account")), /*#__PURE__*/React.createElement("section", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,440px),1fr))",
        gap: "32px 56px",
        paddingBottom: 48
      }
    }, /*#__PURE__*/React.createElement(Standout, {
      statement: "Almost every letter we could read leans to the right.",
      lede: "Of the 26 letter shapes accepted for slant, one stood upright and none leaned left. The rest tilted right, by about 20\xB0 on average.",
      facts: [{
        label: "Mean slant",
        value: /*#__PURE__*/React.createElement(FactValue, {
          fact: F.SLANT_ANGLE_MEAN,
          showCalibration: false
        })
      }, {
        label: "Median",
        value: /*#__PURE__*/React.createElement(FactValue, {
          fact: F.SLANT_ANGLE_MEDIAN,
          showCalibration: false
        })
      }, {
        label: "Right-lean ratio",
        value: /*#__PURE__*/React.createElement(FactValue, {
          fact: F.SLANT_RIGHT_FRACTION,
          showCalibration: false
        })
      }, {
        label: "Observations",
        value: /*#__PURE__*/React.createElement("span", {
          className: "ik-value"
        }, "26")
      }],
      evidence: "COMPUTATIONAL_PROXY",
      evidenceSuffix: "not calibrated"
    }), /*#__PURE__*/React.createElement("figure", {
      style: {
        margin: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "ik-plate",
      style: {
        padding: "26px 26px 20px"
      }
    }, /*#__PURE__*/React.createElement(SlantFan, {
      observations: OBS,
      mean: 20.08
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 18
      }
    }, /*#__PURE__*/React.createElement(RangeBar, {
      label: "Mean slant \xB7 band P05\u2013P95",
      domain: [-90, 90],
      ticks: [-90, -45, 0, 45, 90],
      value: 20.1,
      band: [5.1, 34.6],
      unit: "\xB0"
    }))), /*#__PURE__*/React.createElement("figcaption", {
      className: "ik-figcap"
    }, "Fig. 1 \u2014 Every slant observation, fixed \u221290\xB0 to +90\xB0 scale \xB7 dashed = rejected"))), /*#__PURE__*/React.createElement(ReportSection, {
      id: "closer",
      kicker: "A closer look",
      title: "Where each measurement came from",
      aside: /*#__PURE__*/React.createElement(LayerToggles, {
        value: layers,
        onChange: setLayers
      })
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,300px),1fr))",
        gap: 40
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        gridColumn: "span 2",
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement(HandwritingCanvas, {
      evidence: E,
      layers: layers,
      caption: "Fig. 2 \u2014 Hover or focus the sample and use \u2190/\u2192 to inspect. Analysis canvas 713 \xD7 316 px; margins are measured to the canvas edge."
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(MarginNote, {
      index: 1,
      label: "Baseline",
      active: layers.length === 1 && layers[0] === "baseline",
      onSelect: () => one("baseline"),
      value: /*#__PURE__*/React.createElement(FactValue, {
        fact: F.BASELINE_ANGLE_MEAN
      })
    }, "Lines run almost level, dipping slightly. Stability 0.78 on a 0\u20131 engineering index \u2014 not a percentage."), /*#__PURE__*/React.createElement(MarginNote, {
      index: 2,
      label: "Line spacing",
      active: layers.length === 1 && layers[0] === "spacing",
      onSelect: () => one("spacing"),
      value: /*#__PURE__*/React.createElement(FactValue, {
        fact: F.LINE_SPACING_PX
      })
    }, "Two gaps, 48 px and 46 px. About 2.6 \xD7 your x-height."), /*#__PURE__*/React.createElement(MarginNote, {
      index: 3,
      label: "Right margin",
      active: layers.length === 1 && layers[0] === "margins",
      onSelect: () => one("margins"),
      value: /*#__PURE__*/React.createElement(FactValue, {
        fact: F.MARGIN_RIGHT_REL
      })
    }, "Lines stop well short of the right edge. Left margin is 1.72."), /*#__PURE__*/React.createElement(MarginNote, {
      index: 4,
      label: "Word spacing",
      unavailable: true
    }, "Not measured in this sample. Each line was read as a single word, so there were no gaps to measure.")))), /*#__PURE__*/React.createElement(ReportSection, {
      kicker: "At a glance",
      title: "Measurement families"
    }, /*#__PURE__*/React.createElement("ol", {
      style: {
        listStyle: "none",
        padding: 0,
        margin: 0,
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,300px),1fr))",
        columnGap: 40
      }
    }, FAMILIES.map(([n, s, e]) => /*#__PURE__*/React.createElement("li", {
      key: n,
      style: {
        display: "flex",
        justifyContent: "space-between",
        gap: 12,
        padding: "14px 0",
        borderTop: "1px solid var(--border-hairline)",
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-body)"
      }
    }, n), /*#__PURE__*/React.createElement("span", {
      className: "ik-cap",
      style: {
        color: e === "MEASURED" ? "var(--evidence-measured)" : undefined,
        fontStyle: e === "i" ? "italic" : undefined
      }
    }, s))))), /*#__PURE__*/React.createElement(ReportSection, {
      kicker: "Baseline",
      title: "Your lines stay almost level",
      aside: /*#__PURE__*/React.createElement(EvidenceBadge, {
        evidence: "COMPUTATIONAL_PROXY",
        suffix: "not calibrated"
      })
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,320px),1fr))",
        gap: 40,
        alignItems: "start"
      }
    }, /*#__PURE__*/React.createElement("figure", {
      style: {
        margin: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "ik-plate",
      style: {
        padding: 20
      }
    }, /*#__PURE__*/React.createElement(BaselineTrace, {
      baselines: E.baselines,
      labels: ["−0.20°", "−0.75°", "−0.30°"],
      exaggerate: 6,
      rowHeight: 48
    })), /*#__PURE__*/React.createElement("figcaption", {
      className: "ik-figcap"
    }, "Fig. 3 \u2014 Stored baseline points, vertical deviation \xD7 6")), /*#__PURE__*/React.createElement("dl", {
      style: {
        margin: 0,
        display: "grid",
        gap: 0
      }
    }, [["Mean angle", "BASELINE_ANGLE_MEAN"], ["Spread (SD)", "BASELINE_ANGLE_STD"], ["Waviness", "BASELINE_WAVINESS"], ["Stability", "BASELINE_STABILITY"]].map(([l, k]) => /*#__PURE__*/React.createElement("div", {
      key: k,
      style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "baseline",
        gap: 12,
        padding: "12px 0",
        borderTop: "1px solid var(--border-hairline)",
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("dt", null, l), /*#__PURE__*/React.createElement("dd", {
      style: {
        margin: 0
      }
    }, /*#__PURE__*/React.createElement(FactValue, {
      fact: F[k],
      size: "sm"
    })))), /*#__PURE__*/React.createElement("div", {
      style: {
        paddingTop: 10
      }
    }, /*#__PURE__*/React.createElement(QualityHint, {
      quality: F.BASELINE_ANGLE_MEAN.quality,
      availability: "UNCALIBRATED",
      method: F.BASELINE_ANGLE_MEAN.method_id
    }))))), /*#__PURE__*/React.createElement(ReportSection, {
      kicker: "Page layout",
      title: "Plenty of room on the right",
      aside: /*#__PURE__*/React.createElement(EvidenceBadge, {
        evidence: "COMPUTATIONAL_PROXY",
        suffix: "canvas-relative"
      })
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,320px),1fr))",
        gap: 40,
        alignItems: "center"
      }
    }, /*#__PURE__*/React.createElement(PageMap, {
      frame: E.frame,
      lines: E.lines,
      marginLabels: {
        left: "1.72",
        right: "14.61"
      }
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(RangeBar, {
      label: "Right margin \xB7 \xD7 x-height",
      domain: [0, 20],
      ticks: [0, 5, 10, 15, 20],
      value: 14.61
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        height: 20
      }
    }), /*#__PURE__*/React.createElement(RangeBar, {
      label: "Left margin \xB7 \xD7 x-height",
      domain: [0, 20],
      ticks: [0, 5, 10, 15, 20],
      value: 1.72
    }), /*#__PURE__*/React.createElement("p", {
      className: "ik-hint",
      style: {
        marginTop: 14
      }
    }, "Scale 0\u201320 \xD7 x-height is PROPOSED and needs review. Measured to the analysis canvas edge, not a detected paper edge.")))), /*#__PURE__*/React.createElement(ReportSection, {
      kicker: "Interpretation",
      title: "Readings beyond the measurements"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,300px),1fr))",
        gap: 24
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 22,
        border: "1px solid var(--border-hairline)",
        background: "repeating-linear-gradient(0deg,transparent 0 27px,var(--rule-soft) 27px 28px)"
      }
    }, /*#__PURE__*/React.createElement(EvidenceBadge, {
      evidence: "TRADITIONAL_ASSOCIATION"
    }), /*#__PURE__*/React.createElement("p", {
      className: "ik-prose",
      style: {
        margin: "12px 0 0"
      }
    }, "Traditional graphology interpretations are not included. When added, they will be quoted from named sources and schools, and are not validated psychological assessment.")), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 22,
        border: "1px solid var(--border-hairline)"
      }
    }, /*#__PURE__*/React.createElement(EvidenceBadge, {
      evidence: "AI_SYNTHESIS"
    }), /*#__PURE__*/React.createElement("p", {
      className: "ik-prose",
      style: {
        margin: "12px 0 0"
      }
    }, "\u2302 Premium adds an AI-assisted reading of the measurements above. It explains them and cannot change them."), /*#__PURE__*/React.createElement("p", {
      className: "ik-hint",
      style: {
        margin: "8px 0 0"
      }
    }, "Premium isn't available yet.")))), /*#__PURE__*/React.createElement(ReportSection, {
      kicker: "How to read this report"
    }, /*#__PURE__*/React.createElement(NoticeBar, {
      notices: ["notice.measured", "notice.proxy_uncalibrated", "notice.reference_unavailable", "notice.traditional_not_included", "notice.private_report"],
      locale: locale
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        paddingTop: 12
      }
    }, /*#__PURE__*/React.createElement(ActionBar, {
      actions: ACTIONS,
      locale: locale,
      onAction: k => go(k === "SHARE" ? "share" : k === "COMPARE" ? "compare" : "report")
    })));
  }
  window.ReportScreen = ReportScreen;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/report-screen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/share-screen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
(() => {
  const {
    ShareCard,
    SlantFan,
    BaselineTrace,
    Button,
    EvidenceBadge,
    SampleEvidence: E
  } = window.IK;
  const OBS = E.components.filter(k => k[4] !== null).map(k => ({
    value: k[4],
    accepted: !!k[5]
  }));
  const PLANES = ["paper", "cobalt", "tomato", "butter", "moss"];
  function ShareScreen({
    go
  }) {
    const [moment, setMoment] = React.useState("slant"),
      [plane, setPlane] = React.useState("paper"),
      [fmt, setFmt] = React.useState("square");
    const on = plane === "cobalt" || plane === "moss" ? "var(--on-plane-light)" : "var(--on-plane-dark)";
    const card = moment === "slant" ? {
      kicker: "Slant",
      statement: "Leans right.",
      value: "20.1°",
      valueLabel: "Mean slant · 26 observations",
      visual: /*#__PURE__*/React.createElement(SlantFan, {
        observations: OBS,
        showRejected: false,
        labels: false,
        strokeWidth: 2.5,
        mean: plane === "paper" ? 20.08 : null,
        color: plane === "paper" ? "var(--ink)" : on,
        accent: "var(--pencil)"
      })
    } : {
      kicker: "Baseline",
      statement: "My lines stay almost level.",
      value: "−0.42°",
      valueLabel: "Mean baseline angle · 3 lines",
      visual: /*#__PURE__*/React.createElement(BaselineTrace, {
        baselines: E.baselines,
        exaggerate: 6,
        rowHeight: 90,
        strokeWidth: 4,
        color: plane === "paper" ? "var(--ink)" : on
      })
    };
    const Seg = ({
      v,
      set,
      opts
    }) => /*#__PURE__*/React.createElement("div", {
      role: "radiogroup",
      style: {
        display: "flex",
        flexWrap: "wrap",
        gap: 6
      }
    }, opts.map(([k, l]) => /*#__PURE__*/React.createElement("button", {
      key: k,
      role: "radio",
      "aria-checked": v === k,
      className: "ik-tog",
      "aria-pressed": v === k,
      onClick: () => set(k)
    }, l)));
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,340px),1fr))",
        gap: 56,
        paddingTop: 48
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "ik-cap ik-cap--accent"
    }, "Share"), /*#__PURE__*/React.createElement("h1", {
      className: "ik-section__title"
    }, "Make a card from this report"), /*#__PURE__*/React.createElement("p", {
      className: "ik-prose",
      style: {
        color: "var(--text-muted)"
      }
    }, "Cards show derived results only. Your handwriting and what you wrote are never included."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 22,
        marginTop: 28
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "ik-cap",
      style: {
        marginBottom: 8
      }
    }, "Moment"), /*#__PURE__*/React.createElement(Seg, {
      v: moment,
      set: setMoment,
      opts: [["slant", "Slant"], ["baseline", "Baseline"]]
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "ik-cap",
      style: {
        marginBottom: 8
      }
    }, "Format"), /*#__PURE__*/React.createElement(Seg, {
      v: fmt,
      set: setFmt,
      opts: [["square", "Square 1:1"], ["story", "Story 9:16"]]
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "ik-cap",
      style: {
        marginBottom: 8
      }
    }, "Colour"), /*#__PURE__*/React.createElement(Seg, {
      v: plane,
      set: setPlane,
      opts: PLANES.map(p => [p, p])
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 28,
        borderTop: "1px solid var(--border-hairline)",
        paddingTop: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "ik-cap"
    }, "What this card discloses"), /*#__PURE__*/React.createElement("ul", {
      style: {
        margin: "10px 0 0",
        paddingLeft: 18,
        font: "var(--type-body)"
      }
    }, /*#__PURE__*/React.createElement("li", null, moment === "slant" ? "Mean slant and the slant observation angles" : "Mean baseline angle and the three baseline traces"), /*#__PURE__*/React.createElement("li", null, "Evidence class and calibration status"), /*#__PURE__*/React.createElement("li", null, "Report revision number")), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 10
      }
    }, /*#__PURE__*/React.createElement(EvidenceBadge, {
      evidence: "COMPUTATIONAL_PROXY",
      suffix: "stays on the card"
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 12,
        marginTop: 28,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement(Button, null, "Save image"), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary"
    }, "Create link"), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => go("report")
    }, "Back to report"))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        placeItems: "start center"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        boxShadow: "var(--shadow-sheet)"
      }
    }, /*#__PURE__*/React.createElement(ShareCard, _extends({
      format: fmt,
      plane: plane
    }, card, {
      scale: fmt === "square" ? 0.46 : 0.3
    })))));
  }
  window.ShareScreen = ShareScreen;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/share-screen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/shell.jsx
try { (() => {
(() => {
  function Shell({
    route,
    go,
    children,
    theme,
    setTheme
  }) {
    const nav = [["history", "Reports"], ["compare", "Compare"]];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        minHeight: "100vh",
        background: "var(--surface-page)",
        color: "var(--text-body)"
      }
    }, /*#__PURE__*/React.createElement("a", {
      href: "#main",
      className: "ik-visually-hidden"
    }, "Skip to content"), /*#__PURE__*/React.createElement("header", {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 16,
        flexWrap: "wrap",
        padding: "14px clamp(20px,4vw,56px)",
        borderBottom: "1px solid var(--border-hairline)"
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => go("capture"),
      className: "ik-btn ik-btn--ghost",
      style: {
        font: "500 22px var(--font-serif)",
        padding: 0,
        letterSpacing: "-.01em"
      }
    }, "Inktrospect"), /*#__PURE__*/React.createElement("nav", {
      style: {
        display: "flex",
        gap: 4,
        flexWrap: "wrap",
        alignItems: "center"
      }
    }, nav.map(([k, l]) => /*#__PURE__*/React.createElement("button", {
      key: k,
      onClick: () => go(k),
      className: "ik-btn ik-btn--ghost",
      style: {
        color: route === k ? "var(--text-body)" : "var(--text-muted)",
        textDecoration: route === k ? "underline" : "none",
        textUnderlineOffset: 6
      }
    }, l)), /*#__PURE__*/React.createElement("button", {
      onClick: () => setTheme(theme === "dark" ? "light" : "dark"),
      className: "ik-btn ik-btn--ghost",
      "aria-label": "Toggle dark theme",
      style: {
        color: "var(--text-muted)"
      }
    }, theme === "dark" ? "Paper" : "Night"), /*#__PURE__*/React.createElement("button", {
      onClick: () => go("capture"),
      className: "ik-btn ik-btn--secondary"
    }, "New sample"))), /*#__PURE__*/React.createElement("main", {
      id: "main",
      style: {
        maxWidth: 1180,
        margin: "0 auto",
        padding: "0 clamp(20px,4vw,56px) 80px"
      }
    }, children));
  }
  window.Shell = Shell;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/shell.jsx", error: String((e && e.message) || e) }); }

__ds_ns.BaselineTrace = __ds_scope.BaselineTrace;

__ds_ns.SampleEvidence = __ds_scope.SampleEvidence;

__ds_ns.SampleFacts = __ds_scope.SampleFacts;

__ds_ns.HandwritingCanvas = __ds_scope.HandwritingCanvas;

__ds_ns.LayerToggles = __ds_scope.LayerToggles;

__ds_ns.PageMap = __ds_scope.PageMap;

__ds_ns.RangeBar = __ds_scope.RangeBar;

__ds_ns.SlantFan = __ds_scope.SlantFan;

__ds_ns.SpacingChart = __ds_scope.SpacingChart;

__ds_ns.EvidenceBadge = __ds_scope.EvidenceBadge;

__ds_ns.FactValue = __ds_scope.FactValue;

__ds_ns.NoticeBar = __ds_scope.NoticeBar;

__ds_ns.QualityHint = __ds_scope.QualityHint;

__ds_ns.EVIDENCE_GLYPH = __ds_scope.EVIDENCE_GLYPH;

__ds_ns.ConsentChoice = __ds_scope.ConsentChoice;

__ds_ns.CreditBalance = __ds_scope.CreditBalance;

__ds_ns.JobStatus = __ds_scope.JobStatus;

__ds_ns.UploadField = __ds_scope.UploadField;

__ds_ns.ActionBar = __ds_scope.ActionBar;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.MarginNote = __ds_scope.MarginNote;

__ds_ns.ReportSection = __ds_scope.ReportSection;

__ds_ns.Standout = __ds_scope.Standout;

__ds_ns.ShareCard = __ds_scope.ShareCard;

})();
