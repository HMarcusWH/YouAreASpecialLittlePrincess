# Inktrospect — UX prototype

Interactive design prototype for the Inktrospect app. It uses **Direction A · The Dossier**, the Inktrospect Design System and synthetic fixtures only.

- **File:** `Inktrospect App.dc.html` (open directly)
- **Source of truth:** `HMarcusWH/YouAreASpecialLittlePrincess@main`, `docs/design/` (see `github.md`)
- **Status:** T10 closed **ACCEPTED_WITH_CHANGES** (owner, 29 Sep 2026; `docs/design/ACCEPTED_DOSSIER_REFERENCE.md`). This pass reconciles the prototype with the repository corrections listed there.
- **Companion file:** `Inktrospect Print and Share.dc.html` holds full-size A4/Letter pages and 1080 × 1080 / 1080 × 1920 cards.

---

## 1. How to use it

The left rail is a review tool, not app UI.

| Control | Options |
|---|---|
| Device | iPhone · iPhone 320 pt · Android phone · iPad · Android tablet · Web desktop (1280) · Web 320 px |
| Report version | individual-report/2 (default for new analyses) · individual-report/1 legacy |
| Owner actions | Current capability (projection actions + reasons) · Design target (all enabled) |
| Theme | Paper (light) · Night paper (dark; the specimen plate stays light) |
| Language | English · Svenska |
| Text size | 100% · 200% |
| Motion | Full · Reduced (all durations 0 ms; reveals are instant, never skipped) |
| Zoom | Auto · Fit · 100% |
| Overflow strings | Injects *Bokstavsavståndsvariation* and *Tredjepartsbehandling av bilden* |
| Screen reader | Lists VoiceOver / TalkBack / web reading order for the current screen |

**Journey · state matrix** lists every screen. Click one to open it, then click a state chip to jump straight to that state. Each screen shows its matrix id and a contract note. You can also just walk the journey inside the device: every button works.

Tweaks (host panel): `device` (iphone, small, android, ipad, atablet, web, web320), `theme`, `locale`, `startScreen`.

---

## 2. UX map

### Main journey
```
Landing ─▶ Capture ─▶ Crop & preview ─▶ Permission & upload ─▶ Processing ─▶ First reveal ─▶ Free report
                                                                                              │
          ┌──────────────┬───────────────┬──────────────┬──────────────┬──────────────────────┤
          ▼              ▼               ▼              ▼              ▼                      ▼
      Evidence     Premium offer ─▶ Purchase ─▶ Premium generation ─▶ Premium report     Share · PDF export · Compare
                                                                          │
Reports & history ◀───────────────────────────────────────────────────────┘      Settings & privacy (from Reports)
```

### Screens and states
| # | Screen | Matrix id | States |
|---|---|---|---|
| 01 | Landing | `landing` | signed_out · returning_account · guest_unfinished_analysis · offline_session · session_ended |
| 02 | Capture | *native addition* | guidance · camera · camera_denied (web: file picker) |
| 03 | Crop & preview | `crop_orientation_preview` | ready · exif_rotated · unsupported_format · too_large · too_small · pixel_bomb · completion_in_progress · bytes_changed |
| 04 | Permission & upload | `permission_upload` | consent_unselected · service_processing_required · image_retention_optional · ai_processing_optional · challenge_required · quota_exceeded · notice_not_accepted |
| 05 | Processing | `processing` | QUEUED · RUNNING · SUCCEEDED · FAILED · CANCELLED · owner_transferred · resume_after_refresh · waiting_network · too_many_active_analyses · uploads_disabled · local_file_changed · running_elsewhere (native step list) |
| 06 | First reveal | `first_reveal` | server_owned_highlight_available · no_eligible_highlight · source_image_not_retained · legacy_v1_without_highlight |
| 07 | Free report | `free_report` | complete · partial_missing · uncalibrated · reference_unavailable · image_revoked · original_not_retained |
| 08 | Evidence | *EvidenceView* | baseline_spacing · slant · margins_xheight · all_layers (+ 1×/2× zoom, step inspector) |
| 09 | Premium offer | `premium_offer_consent` | offer · no_credit · cross_platform_credit_not_spendable · commerce_disabled |
| 10 | Purchase | `purchase` | ready · pending · ask_to_buy · cancelled · failed · restored · account_mismatch (+ verifying, granted) |
| 11 | Premium generation | `premium_generation` | queued · running · succeeded · refused · failed_credit_released · not_applicable_no_authorized_image |
| 12 | Premium report | `premium_report` | saved_overlay · omitted_questions_explained · refund_after_spend_owner_decision_pending |
| 13 | Reports & history | `history` | several_revisions · deleted_capture · empty |
| 14 | Compare *(T18 live · T22 planned)* | `pair_invitation_comparison` | comparison_pair_available (+ swap A↔B) · comparison_pair_equal_values · comparison_history_available · insufficient_common_coverage · planned_invitation_sent · planned_invitation_accepted · planned_invitation_declined · planned_invitation_revoked |
| 15 | Share | `share_preview_revocation` | exact_disclosure_preview · sharing_disabled · link_revoked (+ square/story, 5 planes, slant/baseline) |
| 16 | PDF export | `export_preview` | a4 · letter · source_image_omitted · rendering · failed (+ ready) |
| 17 | Settings & privacy | `settings` | permissions · mail_preference_account · mail_preference_guest · logout_device · logout_everywhere · delete_requested · delete_completed · push_denied (native push row) |
| 18 | Report a problem | `report_feedback` (T24) | form · sent · withdrawn · failed |

### Overlays and system UI
- "How your photo is handled" sheet (from Permission, Settings)
- Report "More" menu: iOS action sheet / Android and web dropdown
- Confirm dialogs: withdraw each permission, sign out (device / everywhere), delete report, delete account
- Store purchase sheet (App Store / Google Play / web checkout): **schematic**
- System share sheet for the card PNG and the PDF: **schematic**
- Toasts for saved or confirmed actions; Android FAB for New sample

### Platform conventions
| | iOS / iPadOS | Android | Web |
|---|---|---|---|
| Navigation | Back chevron + label, large title on Reports | Top app bar, back arrow, FAB | Site nav + skip link; menu button under 500 px |
| Menus | Action sheet | Dropdown menu | Dropdown menu |
| Dialogs | Alert | Dialog, text buttons | Dialog |
| Switches | iOS switch (51×31) | M3 switch (52×32) | Switch |
| Screen reader | VoiceOver phrasing | TalkBack phrasing | ARIA roles, `aria-current`, focus ring |

Every native frame is a **design simulation** for T29–T31. It does not imply that React Native components or store integrations exist.

---

## 3. Data and contracts used
| Area | Source |
|---|---|
| Facts, evidence geometry | `fixtures/reports/view.free.json`, `evidence-bundle.json` (via DS `SampleFacts` / `SampleEvidence`) |
| Premium | `view.owner-premium.json` (overlay reference only) |
| Revoked image | `view.owner-image-revoked.json` |
| Share / export | `view.share.json`, `view.export-no-image.json` |
| Feature labels EN/SV, highlight copy, display domains | `content/presentation/v1/presentation.json` (T08A) |
| Notices, reasons, action copy | `packages/report-web/src/messages.ts` via DS `messages.js` |
| API shapes | `packages/api-client/src/client.ts`, `contracts/product/v1/schemas/` |
| Settings copy | `apps/web/app/settings/*` |
| Commerce / native rules | `docs/roadmap/11-mobile-architecture.md`, `14-payments-entitlements-and-commerce.md` |

Rules held throughout: missing is never zero; *not calibrated* is never a percentage; no percentile or rarity claims; evidence classes differ by icon, label and border as well as colour; purchase is separate from permission; links never grant access; share and export never trigger a new model call; the client never selects highlights or holds entitlement authority.

---

## 4. Handoff note — final contract-resync pass

### 4.0 Native app sync (apps/mobile, 4 Oct 2026)
- **Copy:** app chrome copy comes from apps/mobile/src/i18n/copy.ts (EN/SV snapshot in the prototype). It covers home, capture, review, work, settings, account and feedback.
- **Home:** "Start privately" guest session or "Sign in". Offline and session-ended banners.
- **Capture:** camera-denied path.
- **Permission:** notice-not-accepted state.
- **Processing:** the native work-journal steps (PREPARED → SUCCEEDED) plus the waiting, slot, paused and changed-file states.
- **Report a problem (T24):** report-feedback/1 with five categories (Premium-text issue only on Premium revisions). Optional 500-character note, then sent, withdraw or failed.
- **Settings:** push notification row and the system-denied state.
- **Sign-in:** shows "sign-in is not enabled in this build yet" under Current capability.
- **Tokens:** design-tokens/1.0 matches the bound design system value for value; no changes needed.

### 4.1 What changed
- Synced to the moved repository (main at 3099bcf). T10 is accepted; the matrix now has legacy_v1_without_highlight and live T18 comparison states.
- **First Reveal / v2 report:** render the three T08A sections of view.free-v2.json verbatim. No client selection, no local lede.
- **Facts:** v2 states use the view.free-v2.json facts. v1 and Premium (legacy revision 2) use the v1 facts.
- **Missing data:** missing values are never coerced to zero. Prose has no interpolated numbers. Charts, bars and markers render a hatched availability state instead of a 0.
- **Wording:** "letters" is replaced with contract terms (accepted slant observations, detected components, estimated middle-zone height, estimated baselines, image stroke width).
- **Labels and copy:** read from content/presentation/v1/presentation.json. An unknown ID shows "⚠ id · no reviewed label".
- **Evidence badges:** per fact, not per section. Highlight copy carries ✎ Authored content; its supporting fact keeps its own class.
- **Compare:** rebuilt on fixtures/comparisons. Direction enum, native-unit delta, display_domain, coverage and exclusions come from the DTO. Swap uses pair-ba.
- **Owner actions:** follow the projection by default, including disabled reasons.
- **Share card:** short family statement. The reviewed label and observation count sit in the value label. No highlight is copied into share output.
- **Touch loupe:** press and hold (380 ms) opens it, drag moves it, lift closes it, and a quick swipe still scrolls. Previous/Next steppers are the keyboard and screen-reader path.
- **Desktop report:** sticky contents rail and side margin notes. Narrow column kept, as accepted.
- **AI panel:** overflow fixed.
- **New file:** Print & Share canvases, with a fit check on every page and card.

### 4.2 Still illustrative or planned (marked in the UI)
- Premium AI answers and omitted-question copy (overlay reference only).
- Word-spacing values in the "complete" state.
- Error codes, retry-after time.
- Price and AI provider name.
- Store and share system sheets.
- Challenge provider.
- T22 invitation states.
- Synthetic stand-in glyphs on the plate (accepted limitation 6).

### 4.3 T08A mapping (view.free-v2.json)
| Section | Template | content_id | fact_ids |
|---|---|---|---|
| section.highlight.primary | HIGHLIGHT_PRIMARY | content.highlight.v1.slant.right.almost_all | fact.SLANT_RIGHT_FRACTION |
| section.highlight.secondary.1 | HIGHLIGHT_SECONDARY | content.highlight.v1.layout.margins_asymmetric | fact.MARGIN_SYMMETRY |
| section.highlight.secondary.2 | HIGHLIGHT_SECONDARY | content.highlight.v1.baseline.angle_stable | fact.BASELINE_ANGLE_STD |
| no-eligible | HIGHLIGHT_PRIMARY, INELIGIBLE | content.highlight.v1.none | — |
| legacy v1 | — | no highlight slot | — |

### 4.4 Evidence component mapping
| Visual | Repository input |
|---|---|
| HandwritingCanvas plate + loupe | EvidenceBundle: frame_analysis, lines, baselines, components with slant/accepted (evidence-bundle.json / .v2.json via report-core transforms) |
| SlantFan + RangeBar | slant observations; display domain −90…+90 with ±60 acceptance (presentation.json) |
| BaselineTrace | estimated baseline polylines |
| SpacingChart | line-spacing brackets from stored line boxes |
| PageMap | frame + line boxes; margins to canvas edge |
| Compare rows | Comparison.differences[].display_domain, value_from/to, direction |
No component derives a new measurement; empty arrays render a hatched missing state.

### 4.5 Missing-data behaviour
- Availability vocabulary is shown verbatim, mapped to EN/SV text: READY, UNCALIBRATED, MISSING, NOT_IMPLEMENTED, INELIGIBLE, LOCKED, PENDING, FAILED, REVOKED.
- Missing facts get a hatched note with "Not measured in this sample".
- No marker, band or prose value is produced for a missing fact.

### 4.6 EN/SV
- All app copy, presentation labels and highlight content are bilingual.
- Numbers use Intl (sv-SE decimal comma). Dates are system dates only.
- The two overflow strings are injectable.
- **DS strings:** "Evidence layers" is translated in the app's locale layer. The DS needs locale props on LayerToggles and Standout (gap).

### 4.7 Web desktop / Web 320
- Site nav, skip link, focus ring and aria-current.
- Menu collapses under 500 px.
- File picker instead of the camera; web checkout naming.
- Wide report has a sticky contents rail and a figure/notes split.

### 4.8 Native simulations
- iPhone (incl. 320 pt), iPad, Android phone and tablet, with platform nav, sheets, dialogs and switches.
- These are design simulations only (T29–T31 own the real ones).

### 4.9 A4 / Letter
- Eight-page plan: First Reveal → figure → at a glance → sections with every fact in a table → reference → interpretation → notices → colophon.
- Real headings and tables keep print reading order.
- EN/SV, v1/v2 and image present/omitted are switchable.
- Each page reports whether its content fits.
- Production PDFs are T21 (A4 EN 6 pages, SV 7; Letter 7).

### 4.10 Share 1080 × 1080 / 1080 × 1920
- Slant and baseline cards on four planes.
- Safe-area guides: 64 px inset, plus story bands at 250 px top and 340 px bottom.
- Fit check on every card. Content is view.share-v2.json only.

### 4.11 Accessibility
- **Contrast:** faint ink (#8A8070, ≈3.2:1 on paper) is limited to decoration. Rail text moved to muted ink.
- **Targets and text:** 44 px targets; 200% text at 320 pt/px.
- **Screen readers:** reading-order view, role=img text for charts, live regions for status.
- **Motion:** reduced motion sets all durations to 0 ms.
- **Evidence classes:** shown by glyph, label and border, never colour alone.

### 4.12 Remaining contract gaps (owners)
- **T17:** production identity / cross-device recovery.
- **T20:** Premium web, omitted-question copy, refund-after-spend decision.
- **T21:** comparison/history/Premium print parity.
- **T22:** invitations and other-owner release.
- **T29–T31:** native loupe interaction, store sheets, font delivery.
- **T06/T08/T13:** calibration before any population-relative claim.
- **DS:** reason.already_unlocked string; locale props on Standout/LayerToggles.

## T10 acceptance blockers
T10 is already closed by the owner (ACCEPTED_WITH_CHANGES). **No design-side blockers remain.** Remaining items above belong to downstream tasks, not design.

## 5. Files
| File | Purpose |
|---|---|
| Inktrospect App.dc.html | Interactive prototype |
| Inktrospect Print and Share.dc.html | Full-size print and share canvases |
| fixtures/, content/, packages/report-core/src/messages.ts | Repo snapshots read at runtime |
| ios-frame.jsx, android-frame.jsx, web-frame.js | Device frames |
| github.md | Repo link and sync record |
