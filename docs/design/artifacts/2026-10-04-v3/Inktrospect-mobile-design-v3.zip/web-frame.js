(function () {
  const h = React.createElement;
  function WebFrame({ width = 1280, height = 860, dark = false, bg, children }) {
    const chrome = dark ? '#24211D' : '#E4DDD0', fg = dark ? '#B5AC9C' : '#5E574C', field = dark ? '#171512' : '#FBF8F2';
    const dot = c => h('span', { style: { width: 11, height: 11, borderRadius: '50%', background: c, display: 'block' } });
    return h('div', { 'data-om-starter': 'web-frame', style: { width, height, borderRadius: 8, overflow: 'hidden', display: 'flex', flexDirection: 'column', background: bg || field, boxShadow: '0 20px 50px rgba(28,26,23,.18), 0 0 0 1px rgba(28,26,23,.12)' } },
      h('div', { 'aria-hidden': 'true', style: { flex: 'none', height: 40, display: 'flex', alignItems: 'center', gap: 12, padding: '0 14px', background: chrome } },
        width > 400 ? h('div', { style: { display: 'flex', gap: 7 } }, dot('#E0624E'), dot('#E4B43C'), dot('#5BAA56')) : null,
        h('div', { style: { flex: 1, maxWidth: 560, margin: '0 auto', height: 26, borderRadius: 6, background: field, color: fg, font: '400 12px/26px -apple-system,system-ui,sans-serif', textAlign: 'center', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', padding: '0 10px' } }, 'inktrospect.app')),
      h('div', { style: { flex: 1, minHeight: 0, position: 'relative' } }, children));
  }
  window.WebFrame = WebFrame;
})();
