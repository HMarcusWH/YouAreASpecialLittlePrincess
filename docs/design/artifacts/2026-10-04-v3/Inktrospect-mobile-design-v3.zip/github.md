repo: HMarcusWH/YouAreASpecialLittlePrincess
branch: main
path: docs/design

## Last sync
date: 2026-10-04T13:25:58Z

### Updated in this project
- Native app (apps/mobile) copy, home/capture/work/settings states and the T24 Report a problem screen
- Resynced to moved repo state: T10 accepted, legacy_v1_without_highlight, live T18 comparison fixtures
- First Reveal / v2 report read view.free-v2.json sections and facts; projection actions honoured
- Compare rebuilt on fixtures/comparisons (pair-ab/ba/equal, history, no-overlap)
- New Inktrospect Print and Share.dc.html (A4/Letter pages, 1080 square/story cards)

## Sync history
- 2026-09-28T20:36:21Z (30dea9c): presentation snapshot, server-owned highlights, missing-data guards
- 2026-09-28T19:26:00Z: presentation labels, reveal states, display domains, web canvases
- 2026-09-28T02:51:00Z: rail rebuilt against the state matrix; all report, commerce, share, export and settings screens built

## Screen map
| Screen | Repo sources |
|---|---|
| Landing, capture, crop, permission & upload, processing | docs/design/README.md §2, apps/web/app/start, apps/web/app/analyses, packages/api-client/src/client.ts |
| First reveal, Free report, evidence | content/presentation/v1/presentation.json, apps/render/test/render.test.ts, fixtures/reports/view.free.json, view.owner-image-revoked.json, evidence-bundle.json, packages/report-web/src/messages.ts |
| Premium offer, purchase, generation, Premium report | docs/roadmap/14-payments-entitlements-and-commerce.md, 11-mobile-architecture.md, fixtures/reports/view.owner-premium.json, contracts/product/v1/schemas/common.schema.json (answer_state) |
| History, compare | ReportPage, fixtures/comparisons/*.json, contracts/product/v1/schemas/comparison.schema.json |
| Share, export, print & share canvases | fixtures/reports/view.share-v2.json, view.export-v2-no-image.json, docs/release/t21-render-inspection.md, fixtures/reports/view.share.json, view.export-no-image.json, packages/api-client ExportStatus |
| Report a problem (T24), native chrome copy | apps/mobile/src/i18n/copy.ts, apps/mobile/app/reports/[reportId]/feedback.tsx, src/princess_app/domain/feedback |
| Settings | apps/mobile/app/settings.tsx, apps/web/app/settings/NotificationPreferences.tsx, SettingsActions.tsx |
